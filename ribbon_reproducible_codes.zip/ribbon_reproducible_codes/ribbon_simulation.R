rm(list=ls())
source("ribbon_simulation_codes.R")

set.seed(12345)

N<-100
M<-2500
theta<-rnorm(N,0,1)
g<-rnorm(M,0,1)
mu<-rnorm(M,0,0.3)
sigma<-rgamma(M,1,3)

data11<-unimodal_simulation(theta,g,mu,sigma,1)
data21<-unimodal_simulation(theta,g,mu,sigma,2)

#theta<-rnorm(N,0,1)
#g<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu1<-pmin(mu3,mu4)
mu2<-pmax(mu3,mu4)
sigma1<-pmin(sigma3,sigma4)
sigma2<-pmax(sigma3,sigma4)
pi<-rbeta(M,0.5,0.5)

data11<-unimodal_simulation(theta,g,mu,sigma,1)
data21<-unimodal_simulation(theta,g,mu,sigma,2)

data12<-bimodal_simulation(theta,g,mu1,sigma1,mu2,sigma2,pi,1)
data22<-bimodal_simulation(theta,g,mu1,sigma1,mu2,sigma2,pi,2)

save.image(paste0("ribbon_simulation_null_",N,".Rdata"))

rm(list=ls())

source("ribbon_simulation_codes.R")

set.seed(12345)

N<-100
M<-2500
theta1<-rnorm(N,0,1)
g1<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu11<-pmin(mu3,mu4)
mu21<-pmax(mu3,mu4)
sigma11<-pmin(sigma3,sigma4)
sigma21<-pmax(sigma3,sigma4)
pi1<-rbeta(M,0.5,0.5)

theta2<-rnorm(N,0,1)
g2<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu12<-pmin(mu3,mu4)
mu22<-pmax(mu3,mu4)
sigma12<-pmin(sigma3,sigma4)
sigma22<-pmax(sigma3,sigma4)
pi2<-rbeta(M,0.5,0.5)

mu1<-rnorm(M,0,0.1)
sigma1<-rgamma(M,1,3)

mu2<-rnorm(M,0,0.1)
sigma2<-rgamma(M,1,3)

data11<-unimodal_simulation(theta1,g1,mu1,sigma1,1)
data21<-unimodal_simulation(theta2,g2,mu2,sigma2,2)

data12<-bimodal_simulation(theta1,g1,mu11,sigma11,mu21,sigma21,pi1,1)
data22<-bimodal_simulation(theta2,g2,mu12,sigma12,mu22,sigma22,pi2,2)


save.image(paste0("ribbon_simulation_alternative_",N,".Rdata"))




rm(list=ls())
source("ribbon_simulation_codes.R")

set.seed(12345)

N<-1000
M<-2500
theta<-rnorm(N,0,1)
g<-rnorm(M,0,1)
mu<-rnorm(M,0,0.3)
sigma<-rgamma(M,1,3)

data11<-unimodal_simulation(theta,g,mu,sigma,1)
data21<-unimodal_simulation(theta,g,mu,sigma,2)

#theta<-rnorm(N,0,1)
#g<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu1<-pmin(mu3,mu4)
mu2<-pmax(mu3,mu4)
sigma1<-pmin(sigma3,sigma4)
sigma2<-pmax(sigma3,sigma4)
pi<-rbeta(M,0.5,0.5)

data11<-unimodal_simulation(theta,g,mu,sigma,1)
data21<-unimodal_simulation(theta,g,mu,sigma,2)

data12<-bimodal_simulation(theta,g,mu1,sigma1,mu2,sigma2,pi,1)
data22<-bimodal_simulation(theta,g,mu1,sigma1,mu2,sigma2,pi,2)

save.image(paste0("ribbon_simulation_null_",N,".Rdata"))

rm(list=ls())

source("ribbon_simulation_codes.R")

set.seed(12345)

N<-1000
M<-2500
theta1<-rnorm(N,0,1)
g1<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu11<-pmin(mu3,mu4)
mu21<-pmax(mu3,mu4)
sigma11<-pmin(sigma3,sigma4)
sigma21<-pmax(sigma3,sigma4)
pi1<-rbeta(M,0.5,0.5)

theta2<-rnorm(N,0,1)
g2<-rnorm(M,0,1)
mu3<-rnorm(M,0,0.3)
sigma3<-rgamma(M,1,3)
mu4<-rnorm(M,0,0.3)
sigma4<-rgamma(M,1,3)
mu12<-pmin(mu3,mu4)
mu22<-pmax(mu3,mu4)
sigma12<-pmin(sigma3,sigma4)
sigma22<-pmax(sigma3,sigma4)
pi2<-rbeta(M,0.5,0.5)

mu1<-rnorm(M,0,0.1)
sigma1<-rgamma(M,1,3)

mu2<-rnorm(M,0,0.1)
sigma2<-rgamma(M,1,3)

data11<-unimodal_simulation(theta1,g1,mu1,sigma1,1)
data21<-unimodal_simulation(theta2,g2,mu2,sigma2,2)

data12<-bimodal_simulation(theta1,g1,mu11,sigma11,mu21,sigma21,pi1,1)
data22<-bimodal_simulation(theta2,g2,mu12,sigma12,mu22,sigma22,pi2,2)


save.image(paste0("ribbon_simulation_alternative_",N,".Rdata"))










