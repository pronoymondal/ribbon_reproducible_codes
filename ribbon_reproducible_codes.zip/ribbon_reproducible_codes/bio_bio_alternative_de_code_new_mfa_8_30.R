

  rm(list=ls())
  
  load(paste0("splatter_simulation_mfa_30.Rdata"))
  
  library(SingleCellExperiment)

  data<-2^(assays(sim)$LogExprs)
  #data<-assays(sim)$LogExprs
  
  dataaa3<-t(data[,(colData(sim)$Branch==0)])
  dataaa4<-t(data[,(colData(sim)$Branch==1)])
  
  #dataaa1<-dataaa3[,((rowData(sim)$KBranch1==rowData(sim)$KBranch2)&(rowData(sim)$PhiBranch1==rowData(sim)$PhiBranch2)&(rowData(sim)$DeltaBranch1==rowData(sim)$DeltaBranch2))]
  dataaa1<-dataaa3[,((rowData(sim)$KBranch1!=rowData(sim)$KBranch2)|(rowData(sim)$PhiBranch1!=rowData(sim)$PhiBranch2)|(rowData(sim)$DeltaBranch1!=rowData(sim)$DeltaBranch2))]
  dataaa2<-dataaa4[,((rowData(sim)$KBranch1!=rowData(sim)$KBranch2)|(rowData(sim)$PhiBranch1!=rowData(sim)$PhiBranch2)|(rowData(sim)$DeltaBranch1!=rowData(sim)$DeltaBranch2))]
  
    
  dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
  dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
  
  source("differential_expression_code_new7.R")
  
  pval11<-NULL
  pval12<-NULL
  pval21<-NULL
  pval22<-NULL
  pval31<-NULL
  pval32<-NULL
  
  if("stat11"%in%ls())
  {
    pval11<-pchisq(stat11+statt11,2,lower.tail=F)
  }
  if("stat12"%in%ls())
  {
    pval12<-pchisq(stat12+statt12,2,lower.tail=F)
  }
  if("stat21"%in%ls())
  {
    pval21<-pchisq((stat21+statt21),2,lower.tail=F)
  }
  if("stat22"%in%ls())
  {
    pval22<-pchisq((stat22+statt22),2,lower.tail=F)
  }
  if("stat31"%in%ls())
  {
    pval31<-pchisq(stat31+statt31,2,lower.tail=F)
  }
  if("stat32"%in%ls())
  {
    pval32<-pchisq(stat32+statt32,2,lower.tail=F)
  }
  
  
  
  xx<-ls()
  lst<-list()
  for(obj in xx)
  {
    lst[[obj]]<-get(obj)
  }
  #saveRDS(lst,"mydata3.rds")
  lst<-list(pval11=pval11,pval12=pval12,pval21=pval21,pval22=pval22,pval31=pval31,pval32=pval32)
  
  
saveRDS(lst,paste0("bio_simulation_alternative1_new_mfa_8_30.rds"))




