rm(list=ls())
load("GSE64016.Rdata")

d<-abs(mu1-mu2)/(2*sqrt(sig1*sig2))

stat1<-abs(log(prop)-log(1-prop))
stat2<-2*log(d-sqrt(d^2-1))+2*d*sqrt(d^2-1)

sigg<-sig2/sig1
x1<-abs(mu1-mu2)
x2<-sig1*((2*(sigg^4-sigg^2+1)^(3/2)-(2*sigg^6-3*sigg^4-3*sigg^2+2))/(sigg^2))^(1/2)

muu1<-NULL
muu2<-NULL
sigg1<-NULL
sigg2<-NULL
muu0<-NULL
sigg<-NULL
muu<-NULL
root1<-NULL
root2<-NULL
ci1<-NULL
ci2<-NULL
index<-NULL
y1<-NULL
y2<-NULL
pp<-NULL

library(RConics)
for(i in 1:(length(mu1)))
{
	if(is.na(mu1[i]))
	{
		next
	}
	if(mu1[i]<mu2[i])
	{
		muu1[i]<-mu1[i]
		muu2[i]<-mu2[i]
		sigg1[i]<-sig1[i]
		sigg2[i]<-sig2[i]
		pp[i]<-prop[i]
	}else
	{
		muu1[i]<-mu2[i]
		muu2[i]<-mu1[i]
		sigg1[i]<-sig2[i]
		sigg2[i]<-sig1[i]
		pp[i]<-(1-prop[i])
	}
	muu[i]<-(muu2[i]-muu1[i])/sigg1[i]
	sigg[i]<-sigg2[i]/sigg1[i]
	muu0[i]<-sqrt((2*(sigg[i]^4-sigg[i]^2+1)^(3/2)-(2*sigg[i]^6-3*sigg[i]^4-3*sigg[i]^2+2))/(sigg[i]^2))
	if(muu[i]<muu0[i])
	{
		index[i]<-TRUE
	}else
	{
		index[i]<-FALSE
		sss<-cubic(c((sigg[i]^2-1),-(sigg[i]^2-2)*muu[i],-muu[i]^2,muu[i]*sigg[i]^2))
		y1[i]<-min(sss[(sss>0)&(sss<muu[i])])
		y2[i]<-max(sss[(sss>0)&(sss<muu[i])])
		ci1[i]<-1/(1+(sigg[i]^3*y1[i])/(muu[i]-y1[i])*exp(-0.5*y1[i]^2+0.5*(y1[i]-muu[i])^2/(sigg[i]^2)))
		ci2[i]<-1/(1+(sigg[i]^3*y2[i])/(muu[i]-y2[i])*exp(-0.5*y2[i]^2+0.5*(y2[i]-muu[i])^2/(sigg[i]^2)))
	}
	
}

cols<-rep("red",length(x1))
cols[((d>1)&(stat1<stat2))]<-"blue"

num<-sum(na.omit(cols)=="blue")
len<-sum((!is.na(x1))&(!is.na(x2)))


pdf("GSE64016.pdf")
plot(x2,x1,col=cols,xlab=expression(paste(mu[0]*sigma[1])),ylab=expression(abs(mu[1]-mu[2])),main="GSE64016")
dev.off()


muvec<-rep(NA,dim(a1)[1])
prob<-rep(NA,dim(a1)[1])
for(i in 1:(dim(a1)[1]))
{
  if(sum(a1[i,])==0)
  {
    next
  }
  x<-a1[i,]
  muvec[i]<-mean(log(x[x>0]))
  prob[i]<-mean(x>0)
  
}

pdf("GSE64016_mean_and_expression.pdf")
plot(muvec,prob,col="blue",xlab="Mean Exprssion Level",ylab="Proportion of cells being ecpressed",main="")
dev.off()







rm(list=ls())
load("GSe75688.Rdata")
d<-abs(mu1-mu2)/(2*sqrt(sig1*sig2))

stat1<-abs(log(prop)-log(1-prop))
stat2<-2*log(d-sqrt(d^2-1))+2*d*sqrt(d^2-1)

sigg<-sig2/sig1
x1<-abs(mu1-mu2)
x2<-sig1*((2*(sigg^4-sigg^2+1)^(3/2)-(2*sigg^6-3*sigg^4-3*sigg^2+2))/(sigg^2))^(1/2)

muu1<-NULL
muu2<-NULL
sigg1<-NULL
sigg2<-NULL
muu0<-NULL
sigg<-NULL
muu<-NULL
root1<-NULL
root2<-NULL
ci1<-NULL
ci2<-NULL
index<-NULL
y1<-NULL
y2<-NULL
pp<-NULL

library(RConics)
for(i in 1:(length(mu1)))
{
	if(is.na(mu1[i]*mu2[i]*sig1[i]*sig2[i]))
	{
		next
	}
	if(mu1[i]<mu2[i])
	{
		muu1[i]<-mu1[i]
		muu2[i]<-mu2[i]
		sigg1[i]<-sig1[i]
		sigg2[i]<-sig2[i]
		pp[i]<-prop[i]
	}else
	{
		muu1[i]<-mu2[i]
		muu2[i]<-mu1[i]
		sigg1[i]<-sig2[i]
		sigg2[i]<-sig1[i]
		pp[i]<-(1-prop[i])
	}
	muu[i]<-(muu2[i]-muu1[i])/sigg1[i]
	sigg[i]<-sigg2[i]/sigg1[i]
	muu0[i]<-sqrt((2*(sigg[i]^4-sigg[i]^2+1)^(3/2)-(2*sigg[i]^6-3*sigg[i]^4-3*sigg[i]^2+2))/(sigg[i]^2))
	if(muu[i]<muu0[i])
	{
		index[i]<-TRUE
	}else
	{
		index[i]<-FALSE
		sss<-cubic(c((sigg[i]^2-1),-(sigg[i]^2-2)*muu[i],-muu[i]^2,muu[i]*sigg[i]^2))
		y1[i]<-min(sss[(sss>0)&(sss<muu[i])])
		y2[i]<-max(sss[(sss>0)&(sss<muu[i])])
		ci1[i]<-1/(1+(sigg[i]^3*y1[i])/(muu[i]-y1[i])*exp(-0.5*y1[i]^2+0.5*(y1[i]-muu[i])^2/(sigg[i]^2)))
		ci2[i]<-1/(1+(sigg[i]^3*y2[i])/(muu[i]-y2[i])*exp(-0.5*y2[i]^2+0.5*(y2[i]-muu[i])^2/(sigg[i]^2)))
	}
	
}



cols<-rep("red",length(x1))
#cols[((Re(ci1)<pp)&(Re(ci2)>pp))]<-"blue"
cols[((d>1)&(stat1<stat2))]<-"blue"

num<-sum(na.omit(cols)=="blue")
len<-sum((!is.na(x1))&(!is.na(x2)))

pdf("GSE75688.pdf")
plot(x2,x1,col=cols,xlab=expression(paste(mu[0]*sigma[1])),ylab=expression(abs(mu[1]-mu[2])),main="GSE75688")
dev.off()

muvec<-rep(NA,dim(a1)[1])
prob<-rep(NA,dim(a1)[1])
for(i in 1:(dim(a1)[1]))
{
	if(sum(a1[i,])==0)
	{
		next
	}
	x<-a1[i,]
	muvec[i]<-mean(log(x[x>0]))
	prob[i]<-mean(x>0)
	
}

pdf("GSE75688_mean_and_expression.pdf")
plot(muvec,prob,col="blue",xlab="Mean Exprssion Level",ylab="Proportion of cells being ecpressed",main="")
dev.off()




rm(list=ls())
load("GSE64016.Rdata")

props<-colMeans(a1>0)

pdf("GSE64016zeros.pdf")
hist(props,breaks=30,col="red",xlab="Proportion of genes expressed",ylab="Relative Frequency", main="Distribution of proportion of genes being expressed in a cell")
dev.off()


rm(list=ls())
load("GSe75688.Rdata")

props<-colMeans(a1[-1,]>0)
pdf("GSE75688zeros.pdf")
hist(props,breaks=30,col="red",xlab="Proportion of genes expressed",ylab="Relative Frequency", main="Distribution of proportion of genes being expressed in a cell")
dev.off()






