bimodal_estimate<-function(y,lambda=pi,mu=mu,sigma=sigma)
{
  eps<-1
  mu2<-mu[2]
  mu1<-mu[1]
  sig2<-sigma[2]
  sig1<-sigma[1]
  pi<-lambda
  
  while(eps>0.000001)
  {
    mu2old<-mu2
    mu1old<-mu1
    sig2old<-sig2
    sig1old<-sig1
    piold<-pi
    
    ind<-(pi*dnorm(y,mu2,sig2))/((pi*dnorm(y,mu2,sig2))+((1-pi)*dnorm(y,mu1,sig1)))
    ind[ind<0.00000001]<-0.00000001
    ind[ind>0.99999999]<-0.99999999
    mu2<-sum(ind*y)/sum(ind)
    mu1<-sum((1-ind)*y)/sum(1-ind)
    sig2<-sqrt(sum(ind*y^2)/sum(ind)-mu2^2)
    sig1<-sqrt(sum((1-ind)*y^2)/sum(1-ind)-mu1^2)
    pi<-mean(ind)
    eps<-sum(abs(mu1old-mu1))+sum(abs(mu2old-mu2))+sum(abs(sig1old-sig1))+sum(abs(sig2old-sig2))
    print(eps)  
  }
  return(list(mu=c(mu1,mu2),sigma=c(sig1,sig2),lambda=c((1-pi),pi)))
    
}


