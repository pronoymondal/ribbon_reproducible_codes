
rm(list=ls())

N<-100

load(paste("ribbon_simulation_null_",N,".Rdata",sep=""))

library(SingleCellExperiment)

data1<-cbind(data11,data12)
data2<-cbind(data21,data22)


data3<-data1
data4<-data2

library(MAST)
library(scMerge)
#data<-sce_cbind(list(data1,data2),exprs="normalized",method="union")
data<-SingleCellExperiment(t(rbind(data3,data4)))
#x<-rep(0,length(colData(sim)$Group))
#x[(colData(sim)$Group=="Group2")]<-1
x<-c(rep(0,(dim(data3)[1])),rep(1,(dim(data4)[1])))
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
	#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
	mast1<-c(mast1,pval)
	mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="ribbon_estimation_mast_null_100.rds")





