
rm(list=ls())

N<-100

load(paste("ribbon_simulation_alternative_",N,".Rdata",sep=""))

library(SingleCellExperiment)

data1<-cbind(data11,data12)
data2<-cbind(data21,data22)

for(i in 1:(dim(data1)[1]))
{
  data1[i,]<-data1[i,]/sum(data1[i,])*1000000
}
for(i in 1:(dim(data2)[1]))
{
  data2[i,]<-data2[i,]/sum(data2[i,])*1000000
}

dataaa1<-log(1+data1)
dataaa2<-log(1+data2)


dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]

rm(list=setdiff(ls(),c("dataa1","dataa2","N")))
source("differential_expression_code_new_1.R")

pval11<-NULL
pval12<-NULL
pval21<-NULL
pval22<-NULL
pval31<-NULL
pval32<-NULL


if("stat11"%in%ls())
{
  pval11<-pchisq(stat11+statt11,3,lower.tail=F)
}
if("stat12"%in%ls())
{
  pval12<-pchisq(stat12+statt12,6,lower.tail=F)
}
if("stat21"%in%ls())
{
  pval21<-pchisq((stat21+statt21),3,lower.tail=F)
}
if("stat22"%in%ls())
{
  pval22<-pchisq((stat22+statt22),6,lower.tail=F)
}
if("stat31"%in%ls())
{
  pval31<-pchisq(stat31+statt31,3,lower.tail=F)
}
if("stat32"%in%ls())
{
  pval32<-pchisq(stat32+statt32,6,lower.tail=F)
}


lst<-list(pval11=pval11,pval12=pval12,pval21=pval21,pval22=pval22,pval31=pval31,pval32=pval32)
#saveRDS(lst,"mydata3.rds")


saveRDS(lst,paste0("ribbon_simulation_alternative_estimated_",N,".rds"))

