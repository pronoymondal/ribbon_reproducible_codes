
rm(list=ls())
#load("splatter_simulation_1000.Rdata")

a<-readRDS("ribbon_estimation_null_sc2p_100.rds")

bio_sc2p_null1<-a[,4]
bio_sc2p_null2<-a[,10]

a<-readRDS("ribbon_estimation_alternative_sc2p_100.rds") 

bio_sc2p_alt1<-a[,4]
bio_sc2p_alt2<-a[,10]

a<-readRDS("ribbon_estimation_desingle_null_100.rds") 
bio_desingle_null<-a$xde[,20]

a<-readRDS("ribbon_estimation_desingle_alternative_100.rds") 
bio_desingle_alt<-a$xde[,20]

a<-readRDS("ribbon_estimation_mast_null_100.rds")
mast1_null<-a$mast1
mast2_null<-a$mast2

a<-readRDS("ribbon_estimation_mast_alternative_100.rds")
mast1_alt<-a$mast1
mast2_alt<-a$mast2


N<-1000
pvalnull<-NULL
a<-readRDS(paste0("ribbon_simulation_null_estimated_3_100.rds"))
pvalnull1<-c(pvalnull,a$pval11,a$pval12,a$pval21,a$pval22,a$pval31,a$pval32)


N<-1000
pvalalt<-NULL
a<-readRDS(paste0("ribbon_simulation_alternative_estimated_3_100.rds"))
pvalalt1<-c(pvalalt,a$pval11,a$pval12,a$pval21,a$pval22,a$pval31,a$pval32)

N<-1000
pvalnull<-NULL
a<-readRDS(paste0("ribbon_simulation_null_estimated_8_100.rds"))
pvalnull2<-c(pvalnull,a$pval11,a$pval12,a$pval21,a$pval22,a$pval31,a$pval32)


N<-1000
pvalalt<-NULL
a<-readRDS(paste0("ribbon_simulation_alternative_estimated_8_100.rds"))
pvalalt2<-c(pvalalt,a$pval11,a$pval12,a$pval21,a$pval22,a$pval31,a$pval32)
  


roc_bio_bio1<-NULL
roc_bio_bio2<-NULL
roc_bio_sc2p1<-NULL
roc_bio_sc2p2<-NULL
roc_bio_desingle<-NULL
roc_mast1<-NULL
roc_mast2<-NULL


for(i in 1:1000)
{
  roc_bio_bio1[i]<-sum(na.omit(pvalalt1)<quantile(na.omit(pvalnull1),(i/1000)))/length(na.omit(pvalalt1))
  roc_bio_bio2[i]<-sum(na.omit(pvalalt2)<quantile(na.omit(pvalnull2),(i/1000)))/length(na.omit(pvalalt2))
  roc_bio_sc2p1[i]<-sum(na.omit(bio_sc2p_alt1)<quantile(na.omit(bio_sc2p_null1),(i/1000)))/length(na.omit(bio_sc2p_alt1))
  roc_bio_sc2p2[i]<-sum(na.omit(bio_sc2p_alt2)<quantile(na.omit(bio_sc2p_null2),(i/1000)))/length(na.omit(bio_sc2p_alt2))
  roc_bio_desingle[i]<-sum(na.omit(bio_desingle_alt)<quantile(na.omit(bio_desingle_null),(i/1000)))/length(na.omit(bio_desingle_alt))
  roc_mast1[i]<-sum(na.omit(abs(mast1_alt))>quantile(na.omit(abs(mast1_null)),(1-i/5000)))/length(na.omit(abs(mast1_alt)))
  roc_mast2[i]<-sum(na.omit(mast2_alt)<quantile(na.omit(mast2_null),(i/5000)))/length(na.omit(mast2_alt))
}



#Plot for ROC curve when data are generated from RIBBON model I
pdf("roc_ribbon_simulation_100_new.pdf")
plot((1:1000)/1000,roc_bio_bio1[1:1000],col="red",type="l",xlab="FPR",ylab="TPR",ylim=c(0,1))
lines((1:1000)/1000,roc_bio_bio2[1:1000],col="purple")
lines((1:1000)/1000,roc_mast1[1:1000],col="blue")
lines((1:1000)/1000,roc_mast2[1:1000],col="cyan")
lines((1:1000)/1000,roc_bio_sc2p1[1:1000],col="black")
lines((1:1000)/1000,roc_bio_sc2p2[1:1000],col="magenta")
lines((1:1000)/1000,roc_bio_desingle[1:1000],col="green")
legend(0.73,0.62,legend=c("RIBBON I","RIBBON II","MAST I","MAST II","SC2P I","SC2P II","DESingle"),col=c("red","purple","blue","cyan","black","magenta","green"),lty=1)
dev.off()




num<-c(sum(na.omit(pvalnull1)<0.05)/length(na.omit(pvalnull2)),sum(na.omit(pvalnull2)<0.05)/length(na.omit(pvalnull2)),sum(na.omit(abs(mast1_null))>qnorm(0.975))/length(na.omit(mast1_null)),sum(na.omit(abs(mast2_null))>qnorm(0.975))/length(na.omit(mast2_null)),sum(na.omit(bio_sc2p_null1)<0.05)/length(na.omit(bio_sc2p_null1)),sum(na.omit(bio_sc2p_null2)<0.05)/length(na.omit(bio_sc2p_null2)),sum(na.omit(bio_desingle_null)<0.05)/length(na.omit(bio_desingle_null)))
names(num)<-c("RIBBON I","RIBBON II","MAST I","MAST II","SC2P I","SC2P II","DEsingle")
pdf("ribbon_type1_error_100_new.pdf")
barplot(num,col="blue",ylim=c(0,0.3),las=1)
abline(0,0)
dev.off()


num<-c(roc_bio_bio1[250],roc_bio_bio2[250],roc_mast1[250],roc_mast2[250],roc_bio_sc2p1[250],roc_bio_sc2p2[250],roc_bio_desingle[250])
names(num)<-c("RIBBON I","RIBBON II","MAST I","MAST II","SC2P I","SC2P II","DEsingle")
pdf("ribbon_power_100_new.pdf")
barplot(num,col="red",ylim=c(0,1),las=1)
abline(0,0)
dev.off()


num<-c(roc_bio_bio1[50],roc_bio_bio2[50],roc_mast1[50],roc_mast2[50],roc_bio_sc2p1[50],roc_bio_sc2p2[50],roc_bio_desingle[50])
names(num)<-c("RIBBON I","RIBBON II","MAST I","MAST II","SC2P I","SC2P II","DEsingle")
pdf("ribbon_power_new_1percent_100_new.pdf")
barplot(num,col="red",ylim=c(0,1),las=1)
abline(0,0)
dev.off()




  