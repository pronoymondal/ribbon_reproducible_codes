for(num in 1:7)
{
datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_bio_simulated_ks_stat2.data"))
library(scater)

source("ks_statistic.R")
innddex<-1
ks_sc2p_stat<-NULL
ks_sc2p_stat1<-NULL
ks_sc2p_stat2<-NULL
ks_sc2p_stat3<-NULL

YY1<-array(0,dim<-dim(YY))
a41<-array(0,dim<-dim(a4))
for(i in 1:(dim(YY)[1]))
{
YY1[i,]<-YY[i,]/sum(YY[i,])*1000000
a41[i,]<-a4[i,]/sum(a4[i,])*1000000


}

for(j in 1:(dim(a41)[2]))
{
x1<-YY1[,j]
x2<-a41[,j]
ks_sc2p_stat[j]<-ks_statistic(YY1[,j],a41[,j])
ks_sc2p_stat1[j]<-ks_statistic(YY1[(YY1[,j]>0),j],a41[(a41[,j]>0),j])*sqrt(length(x1[x1>0])*length(x2[x2>0])/(length(x1[x1>0])+length(x2[x2>0])))
ks_sc2p_stat2[j]<-abs(length(YY1[(YY1[,j]==0),j])-length(a41[(a41[,j]==0),j]))/length(a41[,j])
ks_sc2p_stat3[j]<-ks_statistic(round(YY[,j]),round(a4[,j]))
print(j)
}


save.image(paste0(datanames[num],"_sc2p_simulated_ks_stat.data"))

}


