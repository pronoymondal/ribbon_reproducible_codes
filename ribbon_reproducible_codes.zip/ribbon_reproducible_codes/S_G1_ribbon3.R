load("S_G1_comparisons.Rdata")

rm(list=setdiff(ls(),c("data31","data41")))

dataaa1<-log(1+t(data31))
dataaa2<-log(1+t(data41))
#dataaa1<-t(data31)
#dataaa2<-t(data41)

dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]


source("differential_expression_code_new3.R")

pval11<-NULL
pval12<-NULL
pval21<-NULL
pval22<-NULL
pval31<-NULL
pval32<-NULL

if("stat11"%in%ls())
{
  pval11<-pchisq(stat11+statt11,3,lower.tail=F)
}
if("stat12"%in%ls())
{
  pval12<-pchisq(stat12+statt12,3,lower.tail=F)
}
if("stat21"%in%ls())
{
  pval21<-pchisq((stat21+statt21),3,lower.tail=F)
}
if("stat22"%in%ls())
{
  pval22<-pchisq((stat22+statt22),3,lower.tail=F)
}
if("stat31"%in%ls())
{
  pval31<-pchisq(stat31+statt31,3,lower.tail=F)
}
if("stat32"%in%ls())
{
  pval32<-pchisq(stat32+statt32,3,lower.tail=F)
}

name11<-colnames(data11)
name12<-colnames(data12)
name21<-colnames(data21)
name22<-colnames(data22)
name31<-colnames(data31)
name32<-colnames(data32)

xx<-ls()
lst<-list()
for(obj in xx)
{
  lst[[obj]]<-get(obj)
}
#saveRDS(lst,"mydata3.rds")
lst<-list(pval11=pval11,pval12=pval12,pval21=pval21,pval22=pval22,pval31=pval31,pval32=pval32,name11=name11,name12=name12,name21=name21,name22=name22,name31=name31,name32=name32)

saveRDS(lst,"S_G1_3.rds")




