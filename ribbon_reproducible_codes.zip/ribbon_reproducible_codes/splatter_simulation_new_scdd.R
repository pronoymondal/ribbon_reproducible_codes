rm(list=ls())
library(splatter)
params = newSCDDParams(nDE=1000,nDP=1000,nDM=1000,nDB=1000,nEE=1000,nEP=1000,nCells=100)

sim<-scDDSimulate(params)


#sim<- splatSimulate(group.prob = c(0.5, 0.5), method = "groups",verbose = FALSE,batchCells=c(1000,1000),de.prob=0.5,seed=0)

save(list=ls(),file="splatter_simulation_scdd.Rdata")



