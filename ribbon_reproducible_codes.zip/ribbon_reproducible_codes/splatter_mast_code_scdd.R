rm(list=ls())

library(MAST)
load(paste0("splatter_simulation_scdd.Rdata"))
library(scMerge)
#data<-sce_cbind(list(data1,data2),exprs="normalized",method="union")
data<-SingleCellExperiment(assays(sim)$counts[1:1000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
	#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
	mast1<-c(mast1,pval)
	mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_1.rds")

data<-SingleCellExperiment(assays(sim)$counts[1001:2000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_2.rds")

data<-SingleCellExperiment(assays(sim)$counts[2001:3000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_3.rds")

data<-SingleCellExperiment(assays(sim)$counts[3001:4000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_4.rds")

data<-SingleCellExperiment(assays(sim)$counts[4001:5000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_5.rds")

data<-SingleCellExperiment(assays(sim)$counts[5001:6000,])
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="splatter_estimation_mast_scdd_6.rds")




