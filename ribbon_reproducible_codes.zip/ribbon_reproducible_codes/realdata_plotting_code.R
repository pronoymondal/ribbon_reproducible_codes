lst<-readRDS("ribbon_cell_cycle_3.rds")
matches_stat1_bio1<-lst$matches_stat1_bio_G1_G2M
lst<-readRDS("ribbon_cell_cycle_8.rds")
matches_stat1_bio2<-lst$matches_stat1_bio_G1_G2M
lst<-readRDS("desingle_cell_cycle.rds")
matches_desingle<-lst$matches_desingle_G1_G2M
lst<-readRDS("sc2p_cell_cycle.rds")
matches_sc2p1<-lst$matches_sc2p1_G1_G2M
matches_sc2p2<-lst$matches_sc2p2_G1_G2M
lst<-readRDS("mast_cell_cycle.rds")
matches_mast1<-lst$matches_mast1_G1_G2M
matches_mast2<-lst$matches_mast2_G1_G2M

alpha<-seq(0.0001,1,0.0001)

fpr_stat1_bio1<-NULL
tpr_stat1_bio1<-NULL
mismatches_stat1_bio1<-NULL
roc_stat1_bio1<-NULL
fpr_stat1_bio2<-NULL
tpr_stat1_bio2<-NULL
mismatches_stat1_bio2<-NULL
roc_stat1_bio2<-NULL
for(i in 1:(length(matches_stat1_bio1)))
{
  mismatches_stat1_bio1[i]<-i-matches_stat1_bio1[i]
}
for(i in 1:(length(matches_stat1_bio1)))
{
  fpr_stat1_bio1[i]<-mismatches_stat1_bio1[i]/max(mismatches_stat1_bio1)
  tpr_stat1_bio1[i]<-matches_stat1_bio1[i]/max(matches_stat1_bio1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio1<=(alpha[k]))
  roc_stat1_bio1[k]<-tpr_stat1_bio1[num]
}

for(i in 1:(length(matches_stat1_bio2)))
{
  mismatches_stat1_bio2[i]<-i-matches_stat1_bio2[i]
}
for(i in 1:(length(matches_stat1_bio2)))
{
  fpr_stat1_bio2[i]<-mismatches_stat1_bio2[i]/max(mismatches_stat1_bio2)
  tpr_stat1_bio2[i]<-matches_stat1_bio2[i]/max(matches_stat1_bio2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio2<=(alpha[k]))
  roc_stat1_bio2[k]<-tpr_stat1_bio2[num]
}


fpr_desingle<-NULL
tpr_desingle<-NULL
mismatches_desingle<-NULL
roc_desingle<-NULL
for(i in 1:(length(matches_desingle)))
{
  mismatches_desingle[i]<-i-matches_desingle[i]
}
for(i in 1:(length(matches_desingle)))
{
  fpr_desingle[i]<-mismatches_desingle[i]/max(mismatches_desingle)
  tpr_desingle[i]<-matches_desingle[i]/max(matches_desingle)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_desingle<=(alpha[k]))
  roc_desingle[k]<-tpr_desingle[num]
}



fpr_sc2p1<-NULL
tpr_sc2p1<-NULL
mismatches_sc2p1<-NULL
roc_sc2p1<-NULL
fpr_sc2p2<-NULL
tpr_sc2p2<-NULL
mismatches_sc2p2<-NULL
roc_sc2p2<-NULL
for(i in 1:(length(matches_sc2p1)))
{
  mismatches_sc2p1[i]<-i-matches_sc2p1[i]
}
for(i in 1:(length(matches_sc2p1)))
{
  fpr_sc2p1[i]<-mismatches_sc2p1[i]/max(mismatches_sc2p1)
  tpr_sc2p1[i]<-matches_sc2p1[i]/max(matches_sc2p1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p1<=(alpha[k]))
  roc_sc2p1[k]<-tpr_sc2p1[num]
}
for(i in 1:(length(matches_sc2p2)))
{
  mismatches_sc2p2[i]<-i-matches_sc2p2[i]
}
for(i in 1:(length(matches_sc2p2)))
{
  fpr_sc2p2[i]<-mismatches_sc2p2[i]/max(mismatches_sc2p2)
  tpr_sc2p2[i]<-matches_sc2p2[i]/max(matches_sc2p2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p2<=(alpha[k]))
  roc_sc2p2[k]<-tpr_sc2p2[num]
}


fpr_mast1<-NULL
tpr_mast1<-NULL
mismatches_mast1<-NULL
roc_mast1<-NULL
fpr_mast2<-NULL
tpr_mast2<-NULL
mismatches_mast2<-NULL
roc_mast2<-NULL
for(i in 1:(length(matches_mast1)))
{
  mismatches_mast1[i]<-i-matches_mast1[i]
}
for(i in 1:(length(matches_mast1)))
{
  fpr_mast1[i]<-mismatches_mast1[i]/max(mismatches_mast1)
  tpr_mast1[i]<-matches_mast1[i]/max(matches_mast1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast1<=(alpha[k]))
  roc_mast1[k]<-tpr_mast1[num]
}
for(i in 1:(length(matches_mast2)))
{
  mismatches_mast2[i]<-i-matches_mast2[i]
}
for(i in 1:(length(matches_mast2)))
{
  fpr_mast2[i]<-mismatches_mast2[i]/max(mismatches_mast2)
  tpr_mast2[i]<-matches_mast2[i]/max(matches_mast2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast2<=(alpha[k]))
  roc_mast2[k]<-tpr_mast2[num]
}





pdf("G1_G2M_comparison1.pdf")
plot(roc_stat1_bio1,type="l",col="red",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio2,col="purple")
lines(roc_desingle,col="green")
lines(roc_sc2p1,col="black")
lines(roc_sc2p2,col="magenta")
lines(roc_mast1,col="blue")
lines(roc_mast2,col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,1000,100))
legend(0,max(roc_stat1_bio1,roc_stat1_bio2,roc_sc2p1,roc_sc2p2,roc_desingle,roc_mast1,roc_mast2),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()

pdf("G1_G2M_comparison_1000.pdf")
plot(roc_stat1_bio2[1:1000],type="l",col="purple",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio1[1:1000],col="red")
lines(roc_desingle[1:1000],col="green")
lines(roc_sc2p1[1:1000],col="black")
lines(roc_sc2p2[1:1000],col="magenta")
lines(roc_mast1[1:1000],col="blue")
lines(roc_mast2[1:1000],col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,0.1,0.01))
legend(0,max(roc_stat1_bio1[1000],roc_stat1_bio2[1000],roc_sc2p1[1000],roc_sc2p2[1000],roc_desingle[1000],roc_mast1[1000],roc_mast2[1000]),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()

lst<-readRDS("ribbon_cell_cycle_3.rds")
matches_stat1_bio1<-lst$matches_stat1_bio_G2M_S
lst<-readRDS("ribbon_cell_cycle_8.rds")
matches_stat1_bio2<-lst$matches_stat1_bio_G2M_S
lst<-readRDS("desingle_cell_cycle.rds")
matches_desingle<-lst$matches_desingle_G2M_S
lst<-readRDS("sc2p_cell_cycle.rds")
matches_sc2p1<-lst$matches_sc2p1_G2M_S
matches_sc2p2<-lst$matches_sc2p2_G2M_S
lst<-readRDS("mast_cell_cycle.rds")
matches_mast1<-lst$matches_mast1_G2M_S
matches_mast2<-lst$matches_mast2_G2M_S

alpha<-seq(0.0001,1,0.0001)

fpr_stat1_bio1<-NULL
tpr_stat1_bio1<-NULL
mismatches_stat1_bio1<-NULL
roc_stat1_bio1<-NULL
fpr_stat1_bio2<-NULL
tpr_stat1_bio2<-NULL
mismatches_stat1_bio2<-NULL
roc_stat1_bio2<-NULL
for(i in 1:(length(matches_stat1_bio1)))
{
  mismatches_stat1_bio1[i]<-i-matches_stat1_bio1[i]
}
for(i in 1:(length(matches_stat1_bio1)))
{
  fpr_stat1_bio1[i]<-mismatches_stat1_bio1[i]/max(mismatches_stat1_bio1)
  tpr_stat1_bio1[i]<-matches_stat1_bio1[i]/max(matches_stat1_bio1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio1<=(alpha[k]))
  roc_stat1_bio1[k]<-tpr_stat1_bio1[num]
}

for(i in 1:(length(matches_stat1_bio2)))
{
  mismatches_stat1_bio2[i]<-i-matches_stat1_bio2[i]
}
for(i in 1:(length(matches_stat1_bio2)))
{
  fpr_stat1_bio2[i]<-mismatches_stat1_bio2[i]/max(mismatches_stat1_bio2)
  tpr_stat1_bio2[i]<-matches_stat1_bio2[i]/max(matches_stat1_bio2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio2<=(alpha[k]))
  roc_stat1_bio2[k]<-tpr_stat1_bio2[num]
}


fpr_desingle<-NULL
tpr_desingle<-NULL
mismatches_desingle<-NULL
roc_desingle<-NULL
for(i in 1:(length(matches_desingle)))
{
  mismatches_desingle[i]<-i-matches_desingle[i]
}
for(i in 1:(length(matches_desingle)))
{
  fpr_desingle[i]<-mismatches_desingle[i]/max(mismatches_desingle)
  tpr_desingle[i]<-matches_desingle[i]/max(matches_desingle)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_desingle<=(alpha[k]))
  roc_desingle[k]<-tpr_desingle[num]
}



fpr_sc2p1<-NULL
tpr_sc2p1<-NULL
mismatches_sc2p1<-NULL
roc_sc2p1<-NULL
fpr_sc2p2<-NULL
tpr_sc2p2<-NULL
mismatches_sc2p2<-NULL
roc_sc2p2<-NULL
for(i in 1:(length(matches_sc2p1)))
{
  mismatches_sc2p1[i]<-i-matches_sc2p1[i]
}
for(i in 1:(length(matches_sc2p1)))
{
  fpr_sc2p1[i]<-mismatches_sc2p1[i]/max(mismatches_sc2p1)
  tpr_sc2p1[i]<-matches_sc2p1[i]/max(matches_sc2p1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p1<=(alpha[k]))
  roc_sc2p1[k]<-tpr_sc2p1[num]
}
for(i in 1:(length(matches_sc2p2)))
{
  mismatches_sc2p2[i]<-i-matches_sc2p2[i]
}
for(i in 1:(length(matches_sc2p2)))
{
  fpr_sc2p2[i]<-mismatches_sc2p2[i]/max(mismatches_sc2p2)
  tpr_sc2p2[i]<-matches_sc2p2[i]/max(matches_sc2p2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p2<=(alpha[k]))
  roc_sc2p2[k]<-tpr_sc2p2[num]
}


fpr_mast1<-NULL
tpr_mast1<-NULL
mismatches_mast1<-NULL
roc_mast1<-NULL
fpr_mast2<-NULL
tpr_mast2<-NULL
mismatches_mast2<-NULL
roc_mast2<-NULL
for(i in 1:(length(matches_mast1)))
{
  mismatches_mast1[i]<-i-matches_mast1[i]
}
for(i in 1:(length(matches_mast1)))
{
  fpr_mast1[i]<-mismatches_mast1[i]/max(mismatches_mast1)
  tpr_mast1[i]<-matches_mast1[i]/max(matches_mast1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast1<=(alpha[k]))
  roc_mast1[k]<-tpr_mast1[num]
}
for(i in 1:(length(matches_mast2)))
{
  mismatches_mast2[i]<-i-matches_mast2[i]
}
for(i in 1:(length(matches_mast2)))
{
  fpr_mast2[i]<-mismatches_mast2[i]/max(mismatches_mast2)
  tpr_mast2[i]<-matches_mast2[i]/max(matches_mast2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast2<=(alpha[k]))
  roc_mast2[k]<-tpr_mast2[num]
}





pdf("G2M_S_comparison1.pdf")
plot(roc_stat1_bio1,type="l",col="red",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio2,col="purple")
lines(roc_desingle,col="green")
lines(roc_sc2p1,col="black")
lines(roc_sc2p2,col="magenta")
lines(roc_mast1,col="blue")
lines(roc_mast2,col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,1000,100))
legend(0,max(roc_stat1_bio1,roc_stat1_bio2,roc_sc2p1,roc_sc2p2,roc_desingle,roc_mast1,roc_mast2),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()

pdf("G2M_S_comparison_1000.pdf")
plot(roc_stat1_bio1[1:1000],type="l",col="red",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio2[1:1000],col="purple")
lines(roc_desingle[1:1000],col="green")
lines(roc_sc2p1[1:1000],col="black")
lines(roc_sc2p2[1:1000],col="magenta")
lines(roc_mast1[1:1000],col="blue")
lines(roc_mast2[1:1000],col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,0.1,0.01))
legend(0,max(roc_stat1_bio1[1000],roc_stat1_bio2[1000],roc_sc2p1[1000],roc_sc2p2[1000],roc_desingle[1000],roc_mast1[1000],roc_mast2[1000]),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()


lst<-readRDS("ribbon_cell_cycle_3.rds")
matches_stat1_bio1<-lst$matches_stat1_bio_S_G1
lst<-readRDS("ribbon_cell_cycle_8.rds")
matches_stat1_bio2<-lst$matches_stat1_bio_S_G1
lst<-readRDS("desingle_cell_cycle.rds")
matches_desingle<-lst$matches_desingle_S_G1
lst<-readRDS("sc2p_cell_cycle.rds")
matches_sc2p1<-lst$matches_sc2p1_S_G1
matches_sc2p2<-lst$matches_sc2p2_S_G1
lst<-readRDS("mast_cell_cycle.rds")
matches_mast1<-lst$matches_mast1_S_G1
matches_mast2<-lst$matches_mast2_S_G1

alpha<-seq(0.0001,1,0.0001)

fpr_stat1_bio1<-NULL
tpr_stat1_bio1<-NULL
mismatches_stat1_bio1<-NULL
roc_stat1_bio1<-NULL
fpr_stat1_bio2<-NULL
tpr_stat1_bio2<-NULL
mismatches_stat1_bio2<-NULL
roc_stat1_bio2<-NULL
for(i in 1:(length(matches_stat1_bio1)))
{
  mismatches_stat1_bio1[i]<-i-matches_stat1_bio1[i]
}
for(i in 1:(length(matches_stat1_bio1)))
{
  fpr_stat1_bio1[i]<-mismatches_stat1_bio1[i]/max(mismatches_stat1_bio1)
  tpr_stat1_bio1[i]<-matches_stat1_bio1[i]/max(matches_stat1_bio1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio1<=(alpha[k]))
  roc_stat1_bio1[k]<-tpr_stat1_bio1[num]
}

for(i in 1:(length(matches_stat1_bio2)))
{
  mismatches_stat1_bio2[i]<-i-matches_stat1_bio2[i]
}
for(i in 1:(length(matches_stat1_bio2)))
{
  fpr_stat1_bio2[i]<-mismatches_stat1_bio2[i]/max(mismatches_stat1_bio2)
  tpr_stat1_bio2[i]<-matches_stat1_bio2[i]/max(matches_stat1_bio2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_stat1_bio2<=(alpha[k]))
  roc_stat1_bio2[k]<-tpr_stat1_bio2[num]
}


fpr_desingle<-NULL
tpr_desingle<-NULL
mismatches_desingle<-NULL
roc_desingle<-NULL
for(i in 1:(length(matches_desingle)))
{
  mismatches_desingle[i]<-i-matches_desingle[i]
}
for(i in 1:(length(matches_desingle)))
{
  fpr_desingle[i]<-mismatches_desingle[i]/max(mismatches_desingle)
  tpr_desingle[i]<-matches_desingle[i]/max(matches_desingle)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_desingle<=(alpha[k]))
  roc_desingle[k]<-tpr_desingle[num]
}



fpr_sc2p1<-NULL
tpr_sc2p1<-NULL
mismatches_sc2p1<-NULL
roc_sc2p1<-NULL
fpr_sc2p2<-NULL
tpr_sc2p2<-NULL
mismatches_sc2p2<-NULL
roc_sc2p2<-NULL
for(i in 1:(length(matches_sc2p1)))
{
  mismatches_sc2p1[i]<-i-matches_sc2p1[i]
}
for(i in 1:(length(matches_sc2p1)))
{
  fpr_sc2p1[i]<-mismatches_sc2p1[i]/max(mismatches_sc2p1)
  tpr_sc2p1[i]<-matches_sc2p1[i]/max(matches_sc2p1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p1<=(alpha[k]))
  roc_sc2p1[k]<-tpr_sc2p1[num]
}
for(i in 1:(length(matches_sc2p2)))
{
  mismatches_sc2p2[i]<-i-matches_sc2p2[i]
}
for(i in 1:(length(matches_sc2p2)))
{
  fpr_sc2p2[i]<-mismatches_sc2p2[i]/max(mismatches_sc2p2)
  tpr_sc2p2[i]<-matches_sc2p2[i]/max(matches_sc2p2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_sc2p2<=(alpha[k]))
  roc_sc2p2[k]<-tpr_sc2p2[num]
}


fpr_mast1<-NULL
tpr_mast1<-NULL
mismatches_mast1<-NULL
roc_mast1<-NULL
fpr_mast2<-NULL
tpr_mast2<-NULL
mismatches_mast2<-NULL
roc_mast2<-NULL
for(i in 1:(length(matches_mast1)))
{
  mismatches_mast1[i]<-i-matches_mast1[i]
}
for(i in 1:(length(matches_mast1)))
{
  fpr_mast1[i]<-mismatches_mast1[i]/max(mismatches_mast1)
  tpr_mast1[i]<-matches_mast1[i]/max(matches_mast1)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast1<=(alpha[k]))
  roc_mast1[k]<-tpr_mast1[num]
}
for(i in 1:(length(matches_mast2)))
{
  mismatches_mast2[i]<-i-matches_mast2[i]
}
for(i in 1:(length(matches_mast2)))
{
  fpr_mast2[i]<-mismatches_mast2[i]/max(mismatches_mast2)
  tpr_mast2[i]<-matches_mast2[i]/max(matches_mast2)
}
for(k in 1:(length(alpha)))
{
  num<-sum(fpr_mast2<=(alpha[k]))
  roc_mast2[k]<-tpr_mast2[num]
}





pdf("S_G1_comparison1.pdf")
plot(roc_stat1_bio1,type="l",col="red",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio2,col="purple")
lines(roc_desingle,col="green")
lines(roc_sc2p1,col="black")
lines(roc_sc2p2,col="magenta")
lines(roc_mast1,col="blue")
lines(roc_mast2,col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,1000,100))
legend(0,max(roc_stat1_bio1,roc_stat1_bio2,roc_sc2p1,roc_sc2p2,roc_desingle,roc_mast1,roc_mast2),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()

pdf("S_G1_comparison_1000.pdf")
plot(roc_stat1_bio1[1:1000],type="l",col="red",xaxt="n",xlab="Total genes discovered",ylab="Number of cell cycle genes")
lines(roc_stat1_bio2[1:1000],col="purple")
lines(roc_desingle[1:1000],col="green")
lines(roc_sc2p1[1:1000],col="black")
lines(roc_sc2p2[1:1000],col="magenta")
lines(roc_mast1[1:1000],col="blue")
lines(roc_mast2[1:1000],col="cyan")
abline(0,1/10000)
axis(1,at=seq(0,1000,100),labels=seq(0,0.1,0.01))
legend(0,max(roc_stat1_bio1[1000],roc_stat1_bio2[1000],roc_sc2p1[1000],roc_sc2p2[1000],roc_desingle[1000],roc_mast1[1000],roc_mast2[1000]),legend=c("RIBBON I","RIBBON II","DEsingle","SC2P I","SC2P II","MAST I","MAST II"),col=c("red","purple","green","black","magenta","blue","cyan"),lwd=1,lty=1)
dev.off()





