load("G2M_S_comparisons.Rdata")

rm(list=setdiff(ls(),c("data31","data41")))

dataaa1<-t(data31)
dataaa2<-t(data41)

dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]

library(SingleCellExperiment)
sim<-SingleCellExperiment(assays=list(counts=t(rbind(dataa1,dataa2))))

colData(sim)$Condition<-as.factor(c(rep(1,(dim(data31)[2])),rep(2,(dim(data41)[2]))))

library(MAST)
library(scMerge)
#data<-sce_cbind(list(data1,data2),exprs="normalized",method="union")
data<-SingleCellExperiment(assays(sim)$counts)
x<-rep(0,length(colData(sim)$Condition))
x[(colData(sim)$Condition==2)]<-1
colData(data)$batch<-x
sca<-SceToSingleCellAssay(data,check_sanity=FALSE)

fit1<-zlm(~batch,sca)

fit2<-summary(fit1, doLRT=TRUE)
fit3<-fit2$datatable
contrast<-as.vector(unlist(fit3$contrast))
component<-as.vector(unlist(fit3$component))
fit4<-fit3[(contrast=="batch")&(component=='logFC'),]
fit5<-fit3[(contrast=="batch")&(component=='H'),]
pval<-fit4$z
pvall<-fit5[,4]



#rm(list=ls())
mast1<-NULL
mast2<-NULL
#load(paste0("bio_simulation_null_mast_",num,".Rdata"))
mast1<-c(mast1,pval)
mast2<-c(mast2,as.numeric(unlist(pvall)))

#save.image(paste0("splatter_estimation_mast_1000.Rdata"))
saveRDS(list(mast1=mast1,mast2=mast2),file="mast_G2M_S.rds")


