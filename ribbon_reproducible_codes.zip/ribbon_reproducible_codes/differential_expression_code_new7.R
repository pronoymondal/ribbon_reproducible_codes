

data<-rbind(dataa1,dataa2)

if(is.null(colnames(data)))
{
  colnames(data)<-1:(dim(data)[2])
  colnames(dataa1)<-1:(dim(dataa1)[2])
  colnames(dataa2)<-1:(dim(dataa2)[2])
}

if(is.null(rownames(data)))
{
  rownames(data)<-1:(dim(data)[1])
  rownames(dataa1)<-1:(dim(dataa1)[1])
  rownames(dataa2)<-1:(dim(dataa2)[1])
}

genes<-colnames(data)
genes1<-genes
genes2<-genes


#E<-data>0
#prob<-colMeans(E>0)
#data1<-data[,(prob>0.03)]
#genenames1<-genes[(prob<=0.03)]
#genes1<-genes[(prob>0.03)]

#E1<-dataa1>0
#prob1<-colMeans(E1>0)
#data11<-dataa1[,(prob1>0.03)]
#genenames11<-genes1[(prob1<=0.03)]
#genes11<-genes1[(prob1>0.03)]

#E2<-dataa2>0
#prob2<-colMeans(E2>0)
#data12<-dataa2[,(prob2>0.03)]
#genenames12<-genes2[(prob2<=0.03)]
#genes12<-genes2[(prob2>0.03)]


sig<-NULL
mu<-NULL
for(j in 1:(dim(data)[2]))
{
  sig[j]<-sd(log(data[(data[,j]>0),j]))
  mu[j]<-mean(log(data[(data[,j]>0),j]))
}


prob<-colMeans(data>0)
data1<-data[,(prob<0.1)]
data2<-data[,((prob>=0.1)&(prob<=0.95))]
data3<-data[,(prob>0.95)]
prob1<-prob[(prob<0.1)]
prob2<-prob[((prob>=0.1)&(prob<=0.95))]
prob3<-prob[(prob>0.95)]

prob1<-colMeans(dataa1>0)
dataa11<-dataa1[,(prob<0.1)]
dataa21<-dataa1[,((prob>=0.1)&(prob<=0.95))]
dataa31<-dataa1[,(prob>0.95)]
prob11<-prob1[(prob<0.1)]
prob21<-prob1[((prob>=0.1)&(prob<=0.95))]
prob31<-prob1[(prob>0.95)]

prob2<-colMeans(dataa2>0)
dataa12<-dataa2[,(prob<0.1)]
dataa22<-dataa2[,((prob>=0.1)&(prob<=0.95))]
dataa32<-dataa2[,(prob>0.95)]
prob12<-prob1[(prob<0.1)]
prob22<-prob1[((prob>=0.1)&(prob<=0.95))]
prob32<-prob1[(prob>0.95)]

if((dim(data2)[2])>0)
{
  source("check_bimodality1.R")
  indd<-check_bimodality(t(data2))
  #indd1<-check_bimodality(t(dataa21))
  #indd2<-check_bimodality(t(dataa22))
  #indd<-indd1*indd2
  
  indd[is.na(indd)]<-0
  #indd1[is.na(indd1)]<-0
  #indd2[is.na(indd2)]<-0
  
  data21<-t(t(data2[,(indd==0)]))
  data22<-t(t(data2[,(indd==1)]))
  
  data211<-t(t(dataa21[,(indd==0)]))
  data212<-t(t(dataa21[,(indd==1)]))
  
  data221<-t(t(dataa22[,(indd==0)]))
  data222<-t(t(dataa22[,(indd==1)]))
  
  prob21<-colMeans(data21>0)
  prob22<-colMeans(data22>0)
  
  prob211<-colMeans(data211>0)
  prob212<-colMeans(data212>0)
  
  prob221<-colMeans(data221>0)
  prob222<-colMeans(data222>0)
}


if((dim(t(t(data1)))[2])>0)
{
  source("check_bimodality1.R")
  indd<-check_bimodality(t(data1))
  #indd1<-check_bimodality(t(dataa11))
  #indd2<-check_bimodality(t(dataa12))
  #indd<-indd1*indd2
  
  indd[is.na(indd)]<-0
  #indd1[is.na(indd1)]<-0
  #indd2[is.na(indd2)]<-0
  
  data11<-t(t(t(t(data1))[,(indd==0)]))
  data12<-t(t(t(t(data1))[,(indd==1)]))
  
  data111<-t(t(t(t(dataa11))[,(indd==0)]))
  data112<-t(t(t(t(dataa11))[,(indd==1)]))
  
  data121<-t(t(t(t(dataa12))[,(indd==0)]))
  data122<-t(t(t(t(dataa12))[,(indd==1)]))
  
}

if((dim(t(t(data3)))[2])>0)
{
  source("check_bimodality1.R")
  indd<-check_bimodality(t(data3))
  #indd1<-check_bimodality(t(dataa31))
  #indd2<-check_bimodality(t(dataa32))
  #indd<-indd1*indd2
  
  indd[is.na(indd)]<-0
  #indd1[is.na(indd1)]<-0
  #indd2[is.na(indd2)]<-0
  
  data31<-t(t(t(t(data3))[,(indd==0)]))
  data32<-t(t(t(t(data3))[,(indd==1)]))
  
  data311<-t(t(t(t(dataa31))[,(indd==0)]))
  data312<-t(t(t(t(dataa31))[,(indd==1)]))
  
  data321<-t(t(t(t(dataa32))[,(indd==0)]))
  data322<-t(t(t(t(dataa32))[,(indd==1)]))
  
}



source("test_degree1_alternative.R")

if("data31"%in%(ls()))
{
if(dim(t(t(data31)))[2]>0)
{
stat31<-likelihood_statistic(t(t(data31)),t(t(data311)),t(t(data321)))
}
}
if("data11"%in%(ls()))
{
if(dim(t(t(data11)))[2]>0)
{
  stat11<-likelihood_statistic(t(t(data11)),t(t(data111)),t(t(data121)))
}
}


source("test_degree1_alternative.R")
if("data32"%in%(ls()))
{
if(dim(t(t(data32)))[2]>0)
{
stat32<-likelihood_statistic(t(t(data32)),t(t(data312)),t(t(data322)))
}
}
if("data12"%in%(ls()))
{
if(dim(t(t(data12)))[2]>0)
{
  stat12<-likelihood_statistic(t(t(data12)),t(t(data112)),t(t(data122)))
}
}

source("test_degree1_alternative.R")
if("data21"%in%(ls()))
{
if(dim(t(t(data21)))[2]>0)
{
  stat21<-likelihood_statistic(t(t(data21)),t(t(data211)),t(t(data221)))
}
}

source("test_degree1_alternative.R")
if("data22"%in%(ls()))
{
if(dim(t(t(data22)))[2]>0)
{
  stat22<-likelihood_statistic(t(t(data22)),t(t(data212)),t(t(data222)))
}
}

source("zero_separate_statistic.R")

if("data21"%in%(ls()))
{
if(dim(t(t(data21)))[2]>0)
{
  statt21<-likelihood_statistic1(t(t(data21>0)),t(t(data211>0)),t(t(data221>0)))
}
}

if("data22"%in%(ls()))
{
if(dim(t(t(data22)))[2]>0)
{
  statt22<-likelihood_statistic1(t(t(data22>0)),t(t(data212>0)),t(t(data222>0)))
}
}


if("data11"%in%(ls()))
{
  if(dim(t(t(data11)))[2]>0)
  {
    statt11<-likelihood_statistic1(t(t(data11>0)),t(t(data111>0)),t(t(data121>0)))
  }
}

if("data12"%in%(ls()))
{
  if(dim(t(t(data12)))[2]>0)
  {
    statt12<-likelihood_statistic1(t(t(data12>0)),t(t(data112>0)),t(t(data122>0)))
  }
}

if("data31"%in%(ls()))
{
  if(dim(t(t(data31)))[2]>0)
  {
    statt31<-likelihood_statistic1(t(t(data31>0)),t(t(data311>0)),t(t(data321>0)))
  }
}

if("data32"%in%(ls()))
{
  if(dim(t(t(data32)))[2]>0)
  {
    statt32<-likelihood_statistic1(t(t(data32>0)),t(t(data312>0)),t(t(data322>0)))
  }
}



