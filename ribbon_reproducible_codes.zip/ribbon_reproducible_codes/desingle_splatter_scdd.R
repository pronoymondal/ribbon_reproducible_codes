rm(list=ls())
load("splatter_simulation_scdd.Rdata")

library(SingleCellExperiment)

library(DEsingle)
xde<-DEsingle(assays(sim)$counts[1:1000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_1.rds")

xde<-DEsingle(assays(sim)$counts[1001:2000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_2.rds")

xde<-DEsingle(assays(sim)$counts[2001:3000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_3.rds")

xde<-DEsingle(assays(sim)$counts[3001:4000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_4.rds")

xde<-DEsingle(assays(sim)$counts[4001:5000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_5.rds")

xde<-DEsingle(assays(sim)$counts[5001:6000,],as.factor(colData(sim)$Condition))

saveRDS(list(xde=xde),file="splatter_estimation_desingle_scdd_6.rds")




