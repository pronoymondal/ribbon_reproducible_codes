load("G1_G2M_comparisons.Rdata")

rm(list=setdiff(ls(),c("data31","data41")))

dataaa1<-t(data31)
dataaa2<-t(data41)

dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]

library(SingleCellExperiment)
sim<-SingleCellExperiment(assays=list(counts=t(rbind(dataa1,dataa2))))

colData(sim)$Group<-as.factor(c(rep(1,(dim(data31)[2])),rep(2,(dim(data41)[2]))))

library(DEsingle)
xde<-DEsingle(assays(sim)$counts,colData(sim)$Group)


saveRDS(list(xde=xde),file="desingle_G1_G2M.rds")

