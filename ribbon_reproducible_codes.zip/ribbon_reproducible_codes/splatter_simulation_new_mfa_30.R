rm(list=ls())
library(splatter)

params<-newMFAParams(seed=0,nCells=60)
sim<-mfaSimulate(params=params)

#sim<- splatSimulate(group.prob = c(0.5, 0.5), method = "groups",verbose = FALSE,batchCells=c(1000,1000),de.prob=0.5,seed=0)

save(list=ls(),file="splatter_simulation_mfa_30.Rdata")



