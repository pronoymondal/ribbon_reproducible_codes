

load(paste0("splatter_simulation_mfa_30.Rdata"))

library(SingleCellExperiment)

data<-exp(assays(sim)$LogExprs)-1
#data<-assays(sim)$counts
data[data>2000000000]<-2000000000

library(DEsingle)
#source("DEsingle1.R")
xde<-DEsingle(data,as.factor(colData(sim)$Branch))

#save.image(paste0("splatter_estimation_desingle_mfa.Rdata"))
saveRDS(list(xde=xde),file="splatter_estimation_desingle_mfa_30.rds")

