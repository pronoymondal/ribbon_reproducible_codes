
rm(list=ls())

N<-100

load(paste("ribbon_simulation_alternative_",N,".Rdata",sep=""))

library(SingleCellExperiment)

data1<-cbind(data11,data12)
data2<-cbind(data21,data22)

colnames(data1)<-1:(dim(data1)[2])
colnames(data2)<-1:(dim(data2)[2])
rownames(data1)<-1:(dim(data1)[1])
rownames(data2)<-1:(dim(data2)[1])

library(SingleCellExperiment)
sim<-SingleCellExperiment(list(counts=t(rbind(data1,data2))))
colData(sim)$Group<-as.factor(c(rep(1,(dim(data1)[1])),rep(2,(dim(data2)[1]))))

library(DEsingle)
xde<-DEsingle(assays(sim)$counts,colData(sim)$Group)

#save.image(paste0("splatter_estimation_desingle_1000.Rdata"))

saveRDS(list(xde=xde),file="ribbon_estimation_desingle_alternative_100.rds")

