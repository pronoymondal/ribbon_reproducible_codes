for(num in 1:7)
{
datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_bio_simulated_ks_stat2.Rdata"))
library(scater)

counter<-1
rowsu1<-rep(0,(dim(a4)[1]))
rowsu2<-rep(0,(dim(a4)[1]))
for(i in 1:(length(table(dd))))
{
	rpc_matrix<-a4[,(dd==as.numeric(names(table(dd)))[i])]
	rowsu1<-rowsu1+rowSums(rpc_matrix)
	steps<-floor(dim(rpc_matrix)[2]/100)+1
    nom<-floor(dim(rpc_matrix)[2]/steps)
    if(steps>1)
    {
    for(kk in 1:(steps-1))
    {
    xxxx<-get(paste0("dat",counter))
    rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
    rpc_matrix1<-rpc_matrix[,(((kk-1)*nom+1):(kk*nom))]
    sumvec<-NULL
    for(j in 1:(dim(rpc_matrix2)[2]))
    {
    	sumvec[j]<-sum(as.numeric(rpc_matrix2[,j]))
    }
    for(i1 in 1:(dim(rpc_matrix2)[1]))
    {
    rowsu1[i1]<-rowsu1[i1]+sum(as.numeric(rpc_matrix1[i1,(!is.na(colSums(rpc_matrix1)))]))
    rowsu2[i1]<-rowsu2[i1]+sum(as.numeric(rpc_matrix2[i1,(!is.na(sumvec))]))
    }
    counter<-counter+1
    }
    xxxx<-get(paste0("dat",counter))
    rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
    rpc_matrix1<-rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))]
    sumvec<-NULL
    for(j in 1:(dim(rpc_matrix2)[2]))
    {
    	sumvec[j]<-sum(as.numeric(rpc_matrix2[,j]))
    }
    for(i1 in 1:(dim(rpc_matrix2)[1]))
    {
    rowsu1[i1]<-rowsu1[i1]+sum(as.numeric(rpc_matrix1[i1,(!is.na(colSums(rpc_matrix1)))]))
    rowsu2[i1]<-rowsu2[i1]+sum(as.numeric(rpc_matrix2[i1,(!is.na(sumvec))]))
    }
    counter<-counter+1
    }else
    {
    xxxx<-get(paste0("dat",counter))
    rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
    rpc_matrix1<-rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))]
    sumvec<-NULL
    for(j in 1:(dim(rpc_matrix2)[2]))
    {
    	sumvec[j]<-sum(as.numeric(rpc_matrix2[,j]))
    }
    for(i1 in 1:(dim(rpc_matrix2)[1]))
    {
    rowsu1[i1]<-rowsu1[i1]+sum(as.numeric(rpc_matrix1[i1,(!is.na(colSums(rpc_matrix1)))]))
    rowsu2[i1]<-rowsu2[i1]+sum(as.numeric(rpc_matrix2[i1,(!is.na(sumvec))]))
    }
    counter<-counter+1	
    }
    
	
}


source("ks_statistic.R")
innddex<-1
ks_desingle_stat<-NULL
ks_desingle_stat1<-NULL
ks_desingle_stat2<-NULL
ks_desingle_stat3<-NULL
counter<-1
for(i in 1:(length(table(dd))))
{
code<-"bio_technical_final3_new6_ignore_new1_improved.R"
#source(code)
rpc_matrix<-a4[,(dd==as.numeric(names(table(dd)))[i])]
steps<-floor(dim(rpc_matrix)[2]/100)+1
nom<-floor(dim(rpc_matrix)[2]/steps)
if(steps>1)
{
for(kk in 1:(steps-1))
{
tau1<-1
tau2<-1
flag<-0
code<-"bio_technical_final3_new6_ignore_new1_improved.R"
#source(code)
#a<-estimate(rpc_matrix[,(((kk-1)*nom+1):(kk*nom))],tau1,tau2,1,flag)
rpc_matrix1<-rpc_matrix[,(((kk-1)*nom+1):(kk*nom))]
xxxx<-get(paste0("dat",counter))
rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
rpc_matrix3<-array(NA,dim<-dim(rpc_matrix1))
rpc_matrix4<-array(NA,dim<-dim(rpc_matrix2))
for(i1 in 1:(dim(rpc_matrix3)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix1[i1,]))))
	{
	if(sum(rpc_matrix1[i1,])>0)
	{
	rpc_matrix3[i1,]<-rpc_matrix1[i1,]/sum(rpc_matrix1[i1,])*1000000
	}else
	{
		rpc_matrix3[i1,]<-rep(0,length(rpc_matrix3[i1,]))
	}
	}
}
for(i1 in 1:(dim(rpc_matrix4)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix2[i1,]))))
	{
	if(sum(rpc_matrix2[i1,])>0)
	{
	rpc_matrix4[i1,]<-rpc_matrix2[i1,]/sum(rpc_matrix2[i1,])*1000000
	}else
	{
		rpc_matrix4[i1,]<-rep(0,length(rpc_matrix4[i1,]))
	}
	}
}

for(j in 1:(dim(rpc_matrix1)[2]))
{
	if(!is.na(as.numeric(rpc_matrix2[,j])))
	{
	x1<-as.numeric(rpc_matrix1[,j])/rowsu1*1000000
	x2<-as.numeric(rpc_matrix2[,j])/rowsu2*1000000
	}else
	{
		x1<-as.numeric(rpc_matrix1[,j])
	    x2<-as.numeric(rpc_matrix2[,j])
	}
	x3<-as.numeric(rpc_matrix1[,j])
	x4<-as.numeric(rpc_matrix2[,j])
	if(!is.na(sum(as.numeric(x2))))
	{
	ks_desingle_stat[innddex]<-ks_statistic(x1,x2)
	ks_desingle_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1[x1>0])*length(x2[x2>0])/(length(x1[x1>0])+length(x2[x2>0])))
	ks_desingle_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
	ks_desingle_stat3[innddex]<-ks_statistic(round(x3),round(x4))
	}
	innddex<-innddex+1
}

#assign(paste("abio",counter,sep=""),a)
if(length(a$cc)>1)
{
#code<-"code_tech3.R"
##source(code)
#aa<-estimate(rpc_matrix[,(((kk-1)*nom+1):(kk*nom))],a)
#assign(paste("aabio",counter,sep=""),aa)
}
counter<-counter+1
print(counter)
}
tau1<-1
tau2<-1
flag<-0
code<-"bio_technical_final3_new6_ignore_new1_improved.R"
#source(code)
#a<-estimate(rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))],tau1,tau2,1,flag)
rpc_matrix1<-rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))]
xxxx<-get(paste0("dat",counter))
rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
rpc_matrix3<-array(NA,dim<-dim(rpc_matrix1))
rpc_matrix4<-array(NA,dim<-dim(rpc_matrix2))
for(i1 in 1:(dim(rpc_matrix3)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix1[i1,]))))
	{
	if(sum(rpc_matrix1[i1,])>0)
	{
	rpc_matrix3[i1,]<-rpc_matrix1[i1,]/sum(rpc_matrix1[i1,])*1000000
	}else
	{
		rpc_matrix3[i1,]<-rep(0,length(rpc_matrix3[i1,]))
	}
	}
}
for(i1 in 1:(dim(rpc_matrix4)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix2[i1,]))))
	{
	if(sum(rpc_matrix2[i1,])>0)
	{
	rpc_matrix4[i1,]<-rpc_matrix2[i1,]/sum(rpc_matrix2[i1,])*1000000
	}else
	{
		rpc_matrix4[i1,]<-rep(0,length(rpc_matrix4[i1,]))
	}
	}
}

for(j in 1:(dim(rpc_matrix1)[2]))
{
	if(!is.na(as.numeric(rpc_matrix2[,j])))
	{
	x1<-as.numeric(rpc_matrix1[,j])/rowsu1*1000000
	x2<-as.numeric(rpc_matrix2[,j])/rowsu2*1000000
	}else
	{
		x1<-as.numeric(rpc_matrix1[,j])
	    x2<-as.numeric(rpc_matrix2[,j])
	}
	x3<-as.numeric(rpc_matrix1[,j])
	x4<-as.numeric(rpc_matrix2[,j])
	if(!is.na(sum(as.numeric(x2))))
	{
	ks_desingle_stat[innddex]<-ks_statistic(x1,x2)
	ks_desingle_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1[x1>0])*length(x2[x2>0])/(length(x1[x1>0])+length(x2[x2>0])))
	ks_desingle_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
	ks_desingle_stat3[innddex]<-ks_statistic(round(x3),round(x4))
	}
	innddex<-innddex+1
}

#assign(paste("abio",counter,sep=""),a)
if(length(a$cc)>1)
{
#code<-"code_tech3.R"
##source(code)
#aa<-estimate(rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))],a)
#assign(paste("aabio",counter,sep=""),aa)
}
counter<-counter+1
print(counter)
}else
{
tau1<-1
tau2<-1
flag<-0
code<-"bio_technical_final3_new6_ignore_new1_improved.R"
#source(code)
#a<-estimate(rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))],tau1,tau2,1,flag)
rpc_matrix1<-rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))]
xxxx<-get(paste0("dat",counter))
rpc_matrix2<-xxxx$data1[(1:(dim(a4)[1])),]
rpc_matrix3<-array(NA,dim<-dim(rpc_matrix1))
rpc_matrix4<-array(NA,dim<-dim(rpc_matrix2))
for(i1 in 1:(dim(rpc_matrix3)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix1[i1,]))))
	{
	if(sum(rpc_matrix1[i1,])>0)
	{
	rpc_matrix3[i1,]<-rpc_matrix1[i1,]/sum(rpc_matrix1[i1,])*1000000
	}else
	{
		rpc_matrix3[i1,]<-rep(0,length(rpc_matrix3[i1,]))
	}
	}
}
for(i1 in 1:(dim(rpc_matrix4)[1]))
{
	if(!is.na(sum(as.numeric(rpc_matrix2[i1,]))))
	{
	if(sum(rpc_matrix2[i1,])>0)
	{
	rpc_matrix4[i1,]<-rpc_matrix2[i1,]/sum(rpc_matrix2[i1,])*1000000
	}else
	{
		rpc_matrix4[i1,]<-rep(0,length(rpc_matrix4[i1,]))
	}
	}
}

for(j in 1:(dim(rpc_matrix1)[2]))
{
	if(!is.na(as.numeric(rpc_matrix2[,j])))
	{
	x1<-as.numeric(rpc_matrix1[,j])/rowsu1*1000000
	x2<-as.numeric(rpc_matrix2[,j])/rowsu2*1000000
	}else
	{
		x1<-as.numeric(rpc_matrix1[,j])
	    x2<-as.numeric(rpc_matrix2[,j])
	}
	x3<-as.numeric(rpc_matrix1[,j])
	x4<-as.numeric(rpc_matrix2[,j])
	if(!is.na(sum(as.numeric(x2))))
	{
	ks_desingle_stat[innddex]<-ks_statistic(x1,x2)
	ks_desingle_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1[x1>0])*length(x2[x2>0])/(length(x1[x1>0])+length(x2[x2>0])))
	ks_desingle_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
	ks_desingle_stat3[innddex]<-ks_statistic(round(x3),round(x4))
	}
	innddex<-innddex+1
}

#assign(paste("abio",counter,sep=""),a)
if(length(a$cc)>1)
{
#code<-"code_tech3.R"
##source(code)
#aa<-estimate(rpc_matrix[,(((steps-1)*nom+1):(dim(rpc_matrix)[2]))],a)
#assign(paste("aabio",counter,sep=""),aa)
}
counter<-counter+1
print(counter)
}
}






save.image(paste0(datanames[num],"_desingle_simulation_ks_stat.Rdata"))


}


