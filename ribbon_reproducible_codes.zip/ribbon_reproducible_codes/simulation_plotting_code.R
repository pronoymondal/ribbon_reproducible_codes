currdir<-getwd()


for(num in 1:7)
{
datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_estimated1.Rdata"))

zumble<-NULL

la4<-dim(a4)[1]
library(scater)
#ribbon_bio_old<-ks_stat4
#ribbon_bio<-c(ks_stat_model11,ks_stat_model12,ks_stat_model21,ks_stat_model22)*sqrt(la4/2)
#ribbon_bio1<-c(ks_stat1_model11,ks_stat1_model12,ks_stat1_model21,ks_stat1_model22)
#ribbon_bio2<-c(ks_stat2_model11,ks_stat2_model12,ks_stat2_model21,ks_stat2_model22)


#index11<-(!is.na(ribbon_bio_old))&(!is.na(ribbon_tech_old))
#index1<-match(c(colnames(data11),colnames(data12),colnames(data21),colnames(data22)),colnames(a4))
index11<-1:(dim(a4)[2])

datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_desingle_simulation_ks_stat.Rdata"))
library(scater)
desingle<-na.omit(ks_desingle_stat[index11])*sqrt(la4/2)
desingle1<-na.omit(ks_desingle_stat1[index11])
desingle2<-na.omit(ks_desingle_stat2[index11])

datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_sc2p_simulated_ks_stat.data"))
library(scater)
sc2p<-na.omit(ks_sc2p_stat[zumble][index11])*sqrt(la4/2)
sc2p1<-na.omit(ks_sc2p_stat1[zumble][index11])
sc2p2<-na.omit(ks_sc2p_stat2[zumble][index11])

datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_mast_simulated_ks_stat.Rdata"))
library(scater)
mast<-na.omit(ks_mast[zumble][index11])*sqrt(la4/2)
mast1<-na.omit(ks_mast1[zumble][index11])
mast2<-na.omit(ks_mast2[zumble][index11])

datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_scDD_ks_stat.Rdata"))
library(scater)
scdd<-na.omit(ks_scdd_stat[zumble][index11])*sqrt(la4/2)
scdd1<-na.omit(ks_scdd_stat1[zumble][index11])
scdd2<-na.omit(ks_scdd_stat2[zumble][index11])

datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")
load(paste0(datanames[num],"_estimated1.Rdata"))

zumble<-NULL

la4<-dim(a4)[1]
library(scater)
#ribbon_bio_old<-ks_stat4
ribbon_bio<-c(ks_stat_model12,ks_stat_model22)*sqrt(la4/2)
ribbon_bio1<-c(ks_stat1_model12,ks_stat1_model22)
ribbon_bio2<-c(ks_stat2_model12,ks_stat2_model22)



setwd(paste0(currdir,"/Plots"))


pdf(paste0(num,"_0.pdf"))
boxplot(ribbon_bio,desingle,sc2p,mast,scdd,xaxt = "n",  xlab = "",col="yellow")
axis(1, labels = FALSE)
labels<-c("RIBBON","DESingle","SC2P","MAST","scDD")
text(x =  seq_along(labels), y = par("usr")[3] -0.3, srt = 45, adj = 1, labels = labels, xpd = TRUE)

meanvec<-round(c(mean(ribbon_bio2),mean(desingle2),mean(sc2p2),mean(mast2),mean(scdd2)),3)
dev.off()


pdf(paste0(num,"_1.pdf"))
boxplot(ribbon_bio1,desingle1,sc2p1,mast1,scdd1,xaxt = "n",  xlab = "",col="yellow")
axis(1, labels = FALSE)
labels<-c("RIBBON","DESingle","SC2P","MAST","scDD")
text(x =  seq_along(labels), y = par("usr")[3] -0.3, srt = 45, adj = 1, labels = labels, xpd = TRUE)

meanvec<-round(c(mean(ribbon_bio2),mean(desingle2),mean(sc2p2),mean(mast2),mean(scdd2)),3)
dev.off()



pdf(paste0(num,"_2.pdf"))
boxplot(ribbon_bio2,desingle2,sc2p2,mast2,scdd2,xaxt = "n",  xlab = "",col="yellow")
axis(1, labels = FALSE)
labels<-c("RIBBON","DESingle","SC2P","MAST","scDD")
text(x =  seq_along(labels), y = par("usr")[3] -0.05, srt = 45, adj = 1, labels = labels, xpd = TRUE)

meanvec<-round(c(mean(ribbon_bio2),mean(desingle2),mean(sc2p2),mean(mast2),mean(scdd2)),3)
dev.off()


setwd(currdir)

print(num)


}








