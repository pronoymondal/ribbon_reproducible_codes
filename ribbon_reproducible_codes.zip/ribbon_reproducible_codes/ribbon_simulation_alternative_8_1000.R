
rm(list=ls())

N<-1000

load(paste("ribbon_simulation_alternative_",N,".Rdata",sep=""))

library(SingleCellExperiment)

data1<-cbind(data11,data12)
data2<-cbind(data21,data22)

for(i in 1:(dim(data1)[1]))
{
  data1[i,]<-data1[i,]/sum(data1[i,])*1000000
}
for(i in 1:(dim(data2)[1]))
{
  data2[i,]<-data2[i,]/sum(data2[i,])*1000000
}

dataaa1<-data1
dataaa2<-data2

dataaa1[dataaa1>0]<-dataaa1[dataaa1>0]+1
dataaa2[dataaa2>0]<-dataaa2[dataaa2>0]+1


dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]

rm(list=setdiff(ls(),c("dataa1","dataa2","N")))

stat11<-NULL
stat12<-NULL
stat21<-NULL
stat22<-NULL
stat31<-NULL
stat32<-NULL

statt11<-NULL
statt12<-NULL
statt21<-NULL
statt22<-NULL
statt31<-NULL
statt32<-NULL

source("differential_expression_code_new7.R")

pval11<-NULL
pval12<-NULL
pval21<-NULL
pval22<-NULL
pval31<-NULL
pval32<-NULL


if(("stat11"%in%ls())&(length(stat11)==length(statt11)))
{
  pval11<-pchisq(stat11+statt11,2,lower.tail=F)
}
if(("stat12"%in%ls())&(length(stat12)==length(statt12)))
{
  pval12<-pchisq(stat12+statt12,2,lower.tail=F)
}
if(("stat21"%in%ls())&(length(stat21)==length(statt21)))
{
  pval21<-pchisq((stat21+statt21),2,lower.tail=F)
}
if(("stat22"%in%ls())&(length(stat22)==length(statt22)))
{
  pval22<-pchisq((stat22+statt22),2,lower.tail=F)
}
if(("stat31"%in%ls())&(length(stat31)==length(statt31)))
{
  pval31<-pchisq(stat31+statt31,2,lower.tail=F)
}
if(("stat32"%in%ls())&(length(stat32)==length(statt32)))
{
  pval32<-pchisq(stat32+statt32,2,lower.tail=F)
}

lst<-list(pval11=pval11,pval12=pval12,pval21=pval21,pval22=pval22,pval31=pval31,pval32=pval32)
#saveRDS(lst,"mydata3.rds")


saveRDS(lst,paste0("ribbon_simulation_alternative_estimated_8_",N,".rds"))

