datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")

for(num in 1:7)
{
load(paste0(datanames[num],"_bio_simulated_ks_stat2.Rdata"))
rm(list=setdiff(ls(),c("a4","datanames","num")))
library(scater)
set.seed(num)

E<-a4>0
a4<-a4[,(colSums(E)>1)]

source("Single_Cell_Simu.R")
source("Simulate_set.R")
source("simuDP.R")
source("findIndex.R")
source("find_FC.R")
library(scater)
library(mclust)

data1<-t(a4)
colnames(data1)<-1:(dim(data1)[2])
rownames(data1)<-1:(dim(data1)[1])
condition<-rep(1,dim(data1)[2])
condition1<-rep(2,dim(data1)[2])
data2<-data1
data3<-data1
colnames(data2)<-paste0(colnames(data1),"1")
colnames(data3)<-paste0(colnames(data1),"2")
names(condition)<-paste0(colnames(data1),"1")
names(condition1)<-paste0(colnames(data1),"2")

sce<-SingleCellExperiment(assays = list(normcounts = cbind(data2,data3)),colData=list(condition=c(condition,condition1)))

nDE<-0
nDP<-0
nDB<-0
nDM<-0
nEE<-0
nEP<-dim(data1)[1]


numSamples<-dim(data1)[2]
seed<-0


SD <- simulateSet(sce, numSamples=numSamples, nDE=nDE, nDP=nDP, nDM=nDM, nDB=nDB, nEE=nEE, nEP=nEP,  plots=FALSE, random.seed=seed)


save.image(paste0(datanames[num],"_scDD_simulated.Rdata"))
}















