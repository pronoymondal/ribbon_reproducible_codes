datanames<-c("HSMM","lung","GSE81730","GSE112507","G1","G2M","S")

for(num in 1:7)
{
load(paste0(datanames[num],"_bio_simulated_ks_stat2.Rdata"))
rm(list=setdiff(ls(),c("a4","datanames","num")))
library(scater)
set.seed(num)

p0<-NULL
mu1<-NULL
sig1<-NULL
for(j in 1:(dim(a4)[2]))
{
	p0[j]<-sum(a4[,j]==0)/length(a4[,j])
	mu1[j]<-mean(log(a4[(a4[,j]>0),j]+1))
	sig1[j]<-sd(log(a4[(a4[,j]>0),j]+1))
	print(j)
}


gendata<-array(NA,dim<-dim(a4))
for(j in 1:(dim(a4)[2]))
{
	for(i in 1:(dim(a4)[1]))
	{
		u1<-runif(1)
		if(u1<p0[j])
		{
			gendata[i,j]<-0
		}else
		{
			gendata[i,j]<-max(exp(rnorm(1,mu1[j],sig1[j]))-1,0)
			if(!is.nan(gendata[i,j]))
			{
			if(gendata[i,j]==0)
			{
				i<-i-1
			}
			}
		}
	}
	print(j)
}

save.image(paste0(datanames[num],"_mast_simulated.Rdata"))



ks_mast<-NULL
ks_mast1<-NULL
ks_mast2<-NULL
source("ks_statistic.R")
for(j in 1:(dim(a4)[2]))
{
	ks_mast[j]<-ks_statistic(gendata[,j],a4[,j])
	ks_mast1[j]<-ks_statistic(gendata[(gendata[,j]>0),j],a4[(a4[,j]>0),j])*sqrt(length(gendata[(gendata[,j]>0),j])*length(a4[(a4[,j]>0),j])/(length(a4[(a4[,j]>0),j])+length(gendata[(gendata[,j]>0),j])))
	ks_mast2[j]<-abs(length(gendata[(gendata[,j]>0),j])-length(a4[(a4[,j]>0),j]))/length(a4[,j])
	print(j)
}

save.image(paste0(datanames[num],"_mast_simulated_ks_stat.Rdata"))

}





