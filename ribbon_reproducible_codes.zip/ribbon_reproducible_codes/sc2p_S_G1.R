load("S_G1_comparisons.Rdata")

rm(list=setdiff(ls(),c("data31","data41")))

dataaa1<-t(data31)
dataaa2<-t(data41)

data3<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
data4<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]




uniq1<-NULL
uniq2<-NULL
for(i in 1:(dim(data3)[1]))
{
  uniq1[i]<-length(unique(round(data3[i,(data3[i,]<=15)])))
}
for(i in 1:(dim(data4)[1]))
{
  uniq2[i]<-length(unique(round(data4[i,(data4[i,]<=15)])))
}
data3<-data3[((uniq1>10)),]
data4<-data4[(uniq2>10),]
data3<-data3[((rowSums(round(data3))>1000)&((rowSums(round(data3))<100000000))),]
data4<-data4[((rowSums(round(data4))>1000)&((rowSums(round(data4))<100000000))),]

library(SingleCellExperiment)
sim<-SingleCellExperiment(assays=list(counts=t(rbind(data3,data4))))
colData(sim)$Group<-as.factor(c(rep(1,(dim(data3)[1])),rep(2,(dim(data4)[1]))))


a41<-rbind(data3,data4)
#a41<-a41[,(colMeans(a41>0)>0.05)]
library(Biobase)
library(SC2P)
design1=data.frame(celltype=c(rep("S1",(dim(data3)[1])),rep("S2",(dim(data4)[1]))))
design1=data.frame(celltype=colData(sim)$Group)
rownames(design1)<-rownames(a41)
phenoData <- new("AnnotatedDataFrame",data=design1)
eset<-ExpressionSet(assayData=t(a41),phenoData=phenoData)
source("basic_fun.R")
source("eset2Phase.R")
sc2p.obj<-eset2Phase(eset)

de3<-twoPhaseDE(sc2p.obj,design="celltype",test.which=1)


#save.image(paste0("splatter_estimation_sc2p_1000.Rdata"))

saveRDS(list(de3=de3),file="sc2p_S_G1.rds")

