load("S_bio_simulated_ks_stat2.Rdata")
rm(list=setdiff(ls(),"a4"))
data<-a4

if(is.null(colnames(data)))
{
  colnames(data)<-1:(dim(data)[2])
}

if(is.null(rownames(data)))
{
  rownames(data)<-1:(dim(data)[1])
}

genes<-colnames(data)


E<-data>0
prob<-colMeans(E>0)
data1<-data[,(prob>0.03)]
genenames1<-genes[(prob<=0.03)]
genes1<-genes[(prob>0.03)]


sig<-NULL
mu<-NULL
for(j in 1:(dim(data)[2]))
{
  sig[j]<-sd(log(data[(data[,j]>0),j]))
  mu[j]<-mean(log(data[(data[,j]>0),j]))
}

data1<-data[,(mu>(-5))]

data<-data1
prob<-colMeans(data>0)
data1<-data[,(prob<0.1)]
data2<-data[,((prob>=0.1)&(prob<=0.95))]
prob1<-prob[(prob<0.1)]
prob2<-prob[((prob>=0.1)&(prob<=0.95))]


source("check_bimodality.R")
indd<-check_bimodality(t(data2))


indd[is.na(indd)]<-0

data21<-data2[,(indd==0)]
data22<-data2[,(indd==1)]

prob21<-colMeans(data21>0)
prob22<-colMeans(data22>0)


gap<-0.05
steps<-floor(0.85/gap)+1

for(i in 1:(steps-1))
{
  lb<-0.1+(i-1)*gap
  ub<-0.1+i*gap
  datt1<-data21[,((prob21>=lb)&(prob21<ub))]
  source("estimation_model1.R")
  xxx1<-estimate(datt1)
  datt2<-data22[,((prob22>=lb)&(prob22<ub))]
  source("estimation_model3_1.R")
  xxx2<-estimate(datt2)
  assign(paste0("var1",i),xxx1)
  assign(paste0("var2",i),xxx2)
  
}


save.image("S_estimated.Rdata")

simulated1<-array(0,dim<-dim(data21))
simulated2<-array(0,dim<-dim(data22))

for(i1 in 1:(steps-1))
{
  lb<-0.1+(i1-1)*gap
  ub<-0.1+i1*gap
  datt1<-data21[,((prob21>=lb)&(prob21<ub))]
  datt2<-data22[,((prob22>=lb)&(prob22<ub))]
  matt1<-array(0,dim<-dim(datt1))
  matt2<-array(0,dim<-dim(datt2))
  lst1<-get(paste0("var1",i1))
  lst2<-get(paste0("var2",i1))
  
  matt<-array(0,dim<-dim(matt1))
  
  alpha1<-lst1$alpha1
  alpha2<-lst1$alpha2
  c<-lst1$c
  mu<-lst1$mu
  sig<-lst1$sig
  c1<-lst1$c1
  n<-length(alpha1)
  
  for(i in 1:n)
  {
    for(j in 1:(length(mu)))
    {
      matt[i,j]<-rnorm(1,(mu[j]+alpha2[i]),sig[j])
    }
  }
  E<-array(0,dim<-c(n,length(mu)))
  for(i in 1:n)
  {
    for(j in 1:(length(mu)))
    {
      E[i,j]<-rbinom(1,1,(pnorm(c[j])*pnorm(c1+mu[j]+alpha1[i])))
    }
  }
  matt1<-E*exp(matt)
  

  matt<-array(0,dim<-dim(matt2))
  
  alpha1<-lst2$alpha1
  alpha2<-lst2$alpha2
  c<-lst2$c
  mu1<-lst2$mu1
  sig1<-lst2$sig1
  mu2<-lst2$mu2
  sig2<-lst2$sig2
  pi<-lst2$pi
  c1<-lst2$c1
  n<-length(alpha1)
    
    for(i in 1:n)
    {
      for(j in 1:(length(mu1)))
      {
        u<-runif(1)
        if(u<pnorm(c[j]))
        {
          u1<-runif(1)
          if(u1<(pi[j]))
          {
            matt[i,j]<-rnorm(1,(mu2[j]),sig2[j])
          }else
          {
            u2<-runif(1)
            if(u2<(pnorm(c1+mu1[j]+alpha1[i])))
            {
              matt[i,j]<-rnorm(1,(mu1[j]+alpha2[i]),sig1[j])  
            }else
            {
              matt[i,j]<-0
            }
            
          }
        }else
        {
          matt[i,j]<-0
        }
        
      }
    }
    E<-(matt!=0)
    matt2<-exp(matt)*E
  
    simulated1[,((prob21>=lb)&(prob21<ub))]<-matt1
    simulated2[,((prob22>=lb)&(prob22<ub))]<-matt2
    print(i1)
}
  

rpc_matrix3<-data21
rpc_matrix4<-simulated1
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model1<-ks_stat
ks_stat1_model1<-ks_stat1
ks_stat2_model1<-ks_stat2



rpc_matrix3<-data22
rpc_matrix4<-simulated2
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model3<-ks_stat
ks_stat1_model3<-ks_stat1
ks_stat2_model3<-ks_stat2


save.image("S_estimated.Rdata")


data3<-data[,(prob<0.1)]
data4<-data[,(prob>0.95)]

source("estimation_model2.R")
xxx4<-estimate(data3)

indd2<-check_bimodality(t(data4))
indd2[is.na(indd2)]<-0

data41<-data4[,(indd2==0)]
data42<-data4[,(indd2==1)]


source("estimation_model2.R")
data41<-data41[,(!is.na(colSums(data41)))]
xxx5<-estimate(data41)


source("estimation_model2_new2.R")
xxx6<-estimate(data42)



for(i1 in 1:(steps-1))
{
  lb<-0.1+(i1-1)*gap
  ub<-0.1+i1*gap
  datt1<-data21[,((prob21>=lb)&(prob21<ub))]
  datt2<-data22[,((prob22>=lb)&(prob22<ub))]
  matt1<-array(0,dim<-dim(datt1))
  matt2<-array(0,dim<-dim(datt2))
  lst1<-get(paste0("var1",i1))
  lst2<-get(paste0("var2",i1))
 
  
  matt<-array(0,dim<-dim(matt1))
  
  alpha1<-lst1$alpha1
  alpha2<-lst1$alpha2
  c<-lst1$c
  mu<-lst1$mu
  sig<-lst1$sig
  c1<-lst1$c1
  n<-length(alpha1)
  
  cupd<-NULL
  c1upd<-NULL
  
  prob3<-colMeans(datt1>0)
  
  for(i in 1:(length(c)))
  {
    p1<-pnorm(c[i])
    p2<-pnorm((c1+mu[i])/sqrt(1+lst1$tau1))
    p1n<-min(sqrt(prob3[i]*(p1/p2)),1)
    p2n<-prob3[i]/p1n
    if(p2n>1)
    {
      p2n<-1
      p1n<-prob3[i]
    }
    cupd[i]<-qnorm(p1n)
    c1upd[i]<-qnorm(p2n)*sqrt(1+lst1$tau1)-mu[i]
    print(i)
  }
  lst1$cupd<-cupd
  lst1$c1upd<-c1upd
  
  alpha1<-lst2$alpha1
  alpha2<-lst2$alpha2
  c<-lst2$c
  mu1<-lst2$mu1
  sig1<-lst2$sig1
  mu2<-lst2$mu2
  sig2<-lst2$sig2
  pi<-lst2$pi
  c1<-lst2$c1
  n<-length(alpha1)
  
  prob3<-colMeans(datt2>0)
  
  for(i in 1:(length(c)))
  {
    p1<-pnorm(c[i])
    p2<-pnorm((c1+mu1[i])/sqrt(1+lst2$tau1))
    p1n<-min(sqrt(prob3[i]*(p1/p2)),1)
    p2n<-prob3[i]/p1n
    if(p2n>1)
    {
      p2n<-1
      p1n<-prob3[i]
    }
    cupd[i]<-qnorm(p1n)
    c1upd[i]<-qnorm(p2n)*sqrt(1+lst2$tau1)-mu1[i]
    print(i)
  }
  lst2$cupd<-cupd
  lst2$c1upd<-c1upd
  
  assign(paste0("var1",i1),lst1)
  assign(paste0("var2",i1),lst2)
   
  print(i1)
  
}



save.image("S_estimated1.Rdata")



simulated1<-array(0,dim<-dim(data21))
simulated2<-array(0,dim<-dim(data22))

for(i1 in 1:(steps-1))
{
  lb<-0.1+(i1-1)*gap
  ub<-0.1+i1*gap
  datt1<-data21[,((prob21>=lb)&(prob21<ub))]
  datt2<-data22[,((prob22>=lb)&(prob22<ub))]
  matt1<-array(0,dim<-dim(datt1))
  matt2<-array(0,dim<-dim(datt2))
  lst1<-get(paste0("var1",i1))
  lst2<-get(paste0("var2",i1))
  
  matt<-array(0,dim<-dim(matt1))
  
  alpha1<-lst1$alpha1
  alpha2<-lst1$alpha2
  c<-lst1$cupd
  mu<-lst1$mu
  sig<-lst1$sig
  c1<-lst1$c1upd
  n<-length(alpha1)
  
  for(i in 1:n)
  {
    for(j in 1:(length(mu)))
    {
      matt[i,j]<-rnorm(1,(mu[j]+alpha2[i]),sig[j])
    }
  }
  E<-array(0,dim<-c(n,length(mu)))
  for(i in 1:n)
  {
    for(j in 1:(length(mu)))
    {
      E[i,j]<-rbinom(1,1,(pnorm(c[j])*pnorm(c1+mu[j]+alpha1[i])))
    }
  }
  matt1<-E*exp(matt)
  
  
  matt<-array(0,dim<-dim(matt2))
  
  alpha1<-lst2$alpha1
  alpha2<-lst2$alpha2
  c<-lst2$cupd
  mu1<-lst2$mu1
  sig1<-lst2$sig1
  mu2<-lst2$mu2
  sig2<-lst2$sig2
  pi<-lst2$pi
  c1<-lst2$c1upd
  n<-length(alpha1)
  
  for(i in 1:n)
  {
    for(j in 1:(length(mu1)))
    {
      u<-runif(1)
      if(u<pnorm(c[j]))
      {
        u1<-runif(1)
        if(u1<(pi[j]))
        {
          matt[i,j]<-rnorm(1,(mu2[j]),sig2[j])
        }else
        {
          u2<-runif(1)
          if(u2<(pnorm(c1+mu1[j]+alpha1[i])))
          {
            matt[i,j]<-rnorm(1,(mu1[j]+alpha2[i]),sig1[j])  
          }else
          {
            matt[i,j]<-0
          }
          
        }
      }else
      {
        matt[i,j]<-0
      }
      
    }
  }
  E<-(matt!=0)
  matt2<-exp(matt)*E
  
  
  
  
  simulated1[,((prob21>=lb)&(prob21<ub))]<-matt1
  simulated2[,((prob22>=lb)&(prob22<ub))]<-matt2
  print(i1)
}

matt3<-array(0,dim<-dim(data3))
matt4<-array(0,dim<-dim(data41))
matt5<-array(0,dim<-dim(data42))


matt<-array(0,dim<-dim(matt3))

alpha<-xxx4$alpha
c<-xxx4$c
mu<-xxx4$mu
sig<-xxx4$sig
n<-length(alpha)

for(i in 1:n)
{
  for(j in 1:(length(mu)))
  {
    matt[i,j]<-rnorm(1,(mu[j]+alpha[i]),sig[j])
  }
}
E<-array(0,dim<-c(n,length(mu)))
for(i in 1:n)
{
  for(j in 1:(length(mu)))
  {
    E[i,j]<-rbinom(1,1,(pnorm(c[j])))
  }
}
matt3<-E*exp(matt)




matt<-array(0,dim<-dim(matt4))

alpha<-xxx5$alpha
c<-xxx5$c
mu<-xxx5$mu
sig<-xxx5$sig
n<-length(alpha)

for(i in 1:n)
{
  for(j in 1:(length(mu)))
  {
    matt[i,j]<-rnorm(1,(mu[j]+alpha[i]),sig[j])
  }
}
E<-array(0,dim<-c(n,length(mu)))
for(i in 1:n)
{
  for(j in 1:(length(mu)))
  {
    E[i,j]<-rbinom(1,1,(pnorm(c[j])))
  }
}
matt4<-E*exp(matt)



matt<-array(0,dim<-dim(matt5))

alpha1<-xxx6$alpha1
alpha2<-xxx6$alpha2
c<-xxx6$c
mu1<-xxx6$mu1
sig1<-xxx6$sig1
mu2<-xxx6$mu2
sig2<-xxx6$sig2
pi<-xxx6$pi
n<-length(alpha1)

for(i in 1:n)
{
  for(j in 1:(length(mu1)))
  {
    u<-runif(1)
    if(u<pnorm(c[j]))
    {
      u1<-runif(1)
      if(u1<(pi[j]))
      {
        matt[i,j]<-rnorm(1,(mu2[j]),sig2[j])
      }else
      {
        u2<-runif(1)
        if(1)
        {
          matt[i,j]<-rnorm(1,(mu1[j]+alpha2[i]),sig1[j])  
        }
        
      }
    }else
    {
      matt[i,j]<-0
    }
    
  }
}
E<-(matt!=0)
matt5<-exp(matt)*E

simulated3<-matt3
simulated4<-matt4
simulated5<-matt5




rpc_matrix3<-data21
rpc_matrix4<-simulated1
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model1<-ks_stat
ks_stat1_model1<-ks_stat1
ks_stat2_model1<-ks_stat2



rpc_matrix3<-data22
rpc_matrix4<-simulated2
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model3<-ks_stat
ks_stat1_model3<-ks_stat1
ks_stat2_model3<-ks_stat2




rpc_matrix3<-data3
rpc_matrix4<-simulated3
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model21<-ks_stat
ks_stat1_model21<-ks_stat1
ks_stat2_model21<-ks_stat2


rpc_matrix3<-data41
rpc_matrix4<-simulated4
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model22<-ks_stat
ks_stat1_model22<-ks_stat1
ks_stat2_model22<-ks_stat2



rpc_matrix3<-data42
rpc_matrix4<-simulated5
source("ks_statistic.R")

ks_stat<-NULL
ks_stat1<-NULL
ks_stat2<-NULL
innddex<-1
for(j in 1:(dim(rpc_matrix3)[2]))
{
  x1<-rpc_matrix3[,j]
  x2<-rpc_matrix4[,j]
  if(!is.na(sum(as.numeric(x2))))
  {
    ks_stat[innddex]<-ks_statistic(x1,x2)
    ks_stat1[innddex]<-ks_statistic(x1[x1>0],x2[x2>0])*sqrt(length(x1)*length(x2)/(length(x1)+length(x2)))
    ks_stat2[innddex]<-abs(length(x1[x1==0])-length(x2[x2==0]))/length(x1)
  }
  innddex<-innddex+1
  print(innddex)
}

ks_stat_model23<-ks_stat
ks_stat1_model23<-ks_stat1
ks_stat2_model23<-ks_stat2




save.image("S_estimated1.Rdata")


