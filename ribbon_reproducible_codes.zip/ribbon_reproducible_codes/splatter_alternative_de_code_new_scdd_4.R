
  rm(list=ls())
  
  load(paste0("splatter_simulation_scdd.Rdata"))
 
  library(SingleCellExperiment)
  data<-assays(sim)$counts
  
  dataa<-data[3001:4000,]
  
  for(j in 1:(dim(dataa)[2]))
  {
    dataa[,j]<-dataa[,j]/sum(dataa[,j])*1000000
  }
  
  dataaa1<-log(1+t(dataa[,(colData(sim)$Condition==1)]))
  dataaa2<-log(1+t(dataa[,(colData(sim)$Condition==2)]))
  
  
  library(SingleCellExperiment)
  
  #dataaa1<-assays(sim)$normalized
  #dataaa2<-assays(data2)$normalized
  
  dataa1<-dataaa1[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
  dataa2<-dataaa2[,((colMeans(dataaa1>0)>0.03)&(colMeans(dataaa2>0)>0.03))]
  
  source("differential_expression_code_new.R")
  
  pval11<-NULL
  pval12<-NULL
  pval21<-NULL
  pval22<-NULL
  pval31<-NULL
  pval32<-NULL
  
  if("stat11"%in%ls())
  {
    pval11<-pchisq(stat11,3,lower.tail=F)
  }
  if("stat12"%in%ls())
  {
    pval12<-pchisq(stat12,6,lower.tail=F)
  }
  if("stat21"%in%ls())
  {
    pval21<-pchisq((stat21+statt21),3,lower.tail=F)
  }
  if("stat22"%in%ls())
  {
    pval22<-pchisq((stat22+statt22),6,lower.tail=F)
  }
  if("stat31"%in%ls())
  {
    pval31<-pchisq(stat31,3,lower.tail=F)
  }
  if("stat32"%in%ls())
  {
    pval32<-pchisq(stat32,6,lower.tail=F)
  }
  
  
  xx<-ls()
  lst<-list()
  for(obj in xx)
  {
    lst[[obj]]<-get(obj)
  }
  #saveRDS(lst,"mydata3.rds")
  lst<-list(pval11=pval11,pval12=pval12,pval21=pval21,pval22=pval22,pval31=pval31,pval32=pval32)
  
  
saveRDS(lst,paste0("splatter_alternative_scdd_4.rds"))



