rm(list=ls())
unimodal_simulation<-function(theta,g,mu,sigma,seed)
{
  set.seed(seed)
  E<-array(0,dim<-c(length(theta),length(g)))
  for(i in 1:(length(theta)))
  {
    for(j in 1:(length(g)))
    {
      E[i,j]<-rbinom(1,1,pnorm(theta[i]+g[j]))
    }
  }
  
  data<-array(0,dim<-c(length(theta),length(g)))
  for(j in 1:(dim(data)[2]))
  {
    for(i in 1:(dim(data)[1]))
    {
      x<-rnorm(1,mu[j],sigma[j])
      if(x>2.4)
      {
        i<-i-1
        next
      }
      data[i,j]<-(exp(x))
    }
  }
  data1<-data*E
  return(data1)
}


bimodal_simulation<-function(theta,g,mu1,sigma1,mu2,sigma2,pi,seed)
{
  set.seed(seed)
  E<-array(0,dim<-c(length(theta),length(g)))
  for(i in 1:(length(theta)))
  {
    for(j in 1:(length(g)))
    {
      E[i,j]<-rbinom(1,1,pnorm(theta[i]+g[j]))
    }
  }
  
  data<-array(0,dim<-c(length(theta),length(g)))
  for(j in 1:(dim(data)[2]))
  { 
    for(i in 1:(dim(data)[1]))
    {
      u<-runif(1)
      if(u<(pi[j]))
      {
        x<-rnorm(1,mu2[j],sigma2[j])
        if(x>2.4)
        {
          i<-i-1
          next
        }
      }else
      {
        x<-rnorm(1,mu1[j],sigma1[j])
        if(x>2.5)
        {
          i<-i-1
          next
        }
      }
      data[i,j]<-(exp(x))
    }
  }
  data1<-data*E
  return(data1)
}

